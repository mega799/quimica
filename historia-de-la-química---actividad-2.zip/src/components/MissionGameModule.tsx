import React, { useState, useEffect } from 'react';
import { MISSIONS } from '../data/missionsData';
import { Mission, Question, Option } from '../types';
import confetti from 'canvas-confetti';
import { Flame, Atom, Sparkles, FlaskConical, CheckCircle2, AlertCircle, RefreshCw, Trophy, HelpCircle, ArrowRight, ShieldCheck, Shuffle } from 'lucide-react';

interface MissionGameProps {
  completedMissions: boolean[];
  attemptsPerMission: number[];
  onMissionComplete: (missionIndex: number, attemptsCount: number) => void;
  onGoToRubric: () => void;
}

// Utility to shuffle an array
function shuffleArray<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Prepare questions for a mission by picking 4 random questions and shuffling their options
const prepareMissionQuestions = (mission: Mission): Question[] => {
  const letterIds = ['a', 'b', 'c', 'd'];
  // Shuffle all questions in pool and pick 4
  const pickedQuestions = shuffleArray(mission.questions).slice(0, 4);

  return pickedQuestions.map((q) => {
    const shuffledOpts: Option[] = shuffleArray(q.options).map((opt, idx) => ({
      ...opt,
      id: letterIds[idx] || String.fromCharCode(97 + idx),
    }));
    return {
      ...q,
      options: shuffledOpts,
    };
  });
};

export const MissionGameModule: React.FC<MissionGameProps> = ({
  completedMissions,
  attemptsPerMission,
  onMissionComplete,
  onGoToRubric,
}) => {
  const [activeMissionIndex, setActiveMissionIndex] = useState<number>(0);
  const [activeQuestions, setActiveQuestions] = useState<Question[]>(() =>
    prepareMissionQuestions(MISSIONS[0])
  );
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [selectedOptionId, setSelectedOptionId] = useState<string | null>(null);
  const [showExplanation, setShowExplanation] = useState<boolean>(false);
  const [isCorrectAnswer, setIsCorrectAnswer] = useState<boolean | null>(null);
  const [showHint, setShowHint] = useState<boolean>(false);
  const [localAttempts, setLocalAttempts] = useState<number[]>(attemptsPerMission);

  const activeMission = MISSIONS[activeMissionIndex];
  const currentQuestion: Question = activeQuestions[currentQuestionIndex] || activeMission.questions[0];

  const getMissionIcon = (iconName: string, className = 'w-5 h-5') => {
    switch (iconName) {
      case 'Flame':
        return <Flame className={className} />;
      case 'Atom':
        return <Atom className={className} />;
      case 'Sparkles':
        return <Sparkles className={className} />;
      case 'FlaskConical':
        return <FlaskConical className={className} />;
      default:
        return <Flame className={className} />;
    }
  };

  const triggerVictoryConfetti = () => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
    });
  };

  const handleSelectOption = (optionId: string) => {
    if (showExplanation) return;
    setSelectedOptionId(optionId);
  };

  const handleSubmitAnswer = () => {
    if (!selectedOptionId) return;

    const chosenOption = currentQuestion.options.find((o) => o.id === selectedOptionId);
    const correct = chosenOption?.isCorrect || false;

    setIsCorrectAnswer(correct);
    setShowExplanation(true);

    if (correct) {
      // If correct and it's the last question in the active questions set -> MISSION PASSED!
      if (currentQuestionIndex === activeQuestions.length - 1) {
        triggerVictoryConfetti();
        const finalAttempts = localAttempts[activeMissionIndex] || 1;
        onMissionComplete(activeMissionIndex, finalAttempts);
      }
    } else {
      // If incorrect, increment attempts for this mission!
      const newAttempts = [...localAttempts];
      newAttempts[activeMissionIndex] = (newAttempts[activeMissionIndex] || 1) + 1;
      setLocalAttempts(newAttempts);
    }
  };

  const handleNextQuestion = () => {
    setSelectedOptionId(null);
    setShowExplanation(false);
    setIsCorrectAnswer(null);
    setShowHint(false);

    if (currentQuestionIndex < activeQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handleRestartMission = () => {
    // Generate fresh question set and shuffled options on restart
    setActiveQuestions(prepareMissionQuestions(activeMission));
    setCurrentQuestionIndex(0);
    setSelectedOptionId(null);
    setShowExplanation(false);
    setIsCorrectAnswer(null);
    setShowHint(false);
  };

  const handleSelectMission = (index: number) => {
    setActiveMissionIndex(index);
    setActiveQuestions(prepareMissionQuestions(MISSIONS[index]));
    setCurrentQuestionIndex(0);
    setSelectedOptionId(null);
    setShowExplanation(false);
    setIsCorrectAnswer(null);
    setShowHint(false);
  };

  const allMissionsCompleted = completedMissions.every((c) => c);

  return (
    <div className="space-y-6">
      {/* Missions Progress Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {MISSIONS.map((m, idx) => {
          const isCompleted = completedMissions[idx];
          const isCurrent = idx === activeMissionIndex;
          const attempts = localAttempts[idx] || 1;

          return (
            <button
              key={m.id}
              onClick={() => handleSelectMission(idx)}
              className={`p-4 rounded-2xl border text-left transition-all relative overflow-hidden flex flex-col justify-between ${
                isCompleted
                  ? 'bg-slate-900/90 border-emerald-500/50 text-white shadow-lg shadow-emerald-950/30'
                  : isCurrent
                  ? 'bg-slate-800 border-cyan-500 text-white ring-2 ring-cyan-500/30 shadow-xl'
                  : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800/50">
                  Misión {m.id}
                </span>
                <div className="flex items-center gap-1.5">
                  {isCompleted ? (
                    <span className="flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Lograda
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-mono bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      Intento #{attempts}
                    </span>
                  )}
                </div>
              </div>

              <div className="space-y-1">
                <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                  <span className={isCompleted ? 'text-emerald-400' : 'text-cyan-400'}>
                    {getMissionIcon(m.icon, 'w-4 h-4')}
                  </span>
                  {m.stageName}
                </h4>
                <p className="text-xs text-slate-400 line-clamp-1">{m.subtitle}</p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Mission Active Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-4 sm:space-y-6 relative overflow-hidden">
        {/* Mission Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
              {getMissionIcon(activeMission.icon, 'w-5 h-5 sm:w-6 sm:h-6')}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-widest text-cyan-400">
                  {activeMission.title}
                </span>
                <span className="text-[11px] text-slate-400 font-mono">
                  (Intento #{localAttempts[activeMissionIndex] || 1})
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white">{activeMission.subtitle}</h3>
            </div>
          </div>

          <div className="flex items-center justify-between sm:justify-end w-full sm:w-auto gap-3">
            <span className="text-[11px] sm:text-xs text-slate-400 flex items-center gap-1 font-mono">
              <Shuffle className="w-3.5 h-3.5 text-cyan-400" /> Preguntas aleatorias
            </span>
            <div className="flex gap-1">
              {activeQuestions.map((_, qIdx) => (
                <div
                  key={qIdx}
                  className={`w-6 sm:w-7 h-2 rounded-full transition-all ${
                    qIdx < currentQuestionIndex
                      ? 'bg-emerald-500'
                      : qIdx === currentQuestionIndex
                      ? 'bg-cyan-400 shadow-sm shadow-cyan-400/50'
                      : 'bg-slate-800'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Question Area */}
        <div className="space-y-4 sm:space-y-6">
          <div className="space-y-1.5 sm:space-y-2">
            <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">
              Pregunta {currentQuestionIndex + 1} de {activeQuestions.length}: {currentQuestion.title}
            </span>
            <h4 className="text-sm sm:text-lg font-bold text-white leading-snug">
              {currentQuestion.prompt}
            </h4>
          </div>

          {/* Hint Button & Drawer */}
          <div>
            {!showHint ? (
              <button
                onClick={() => setShowHint(true)}
                className="flex items-center gap-1.5 text-xs text-amber-400/90 hover:text-amber-300 font-medium transition-colors py-1"
              >
                <HelpCircle className="w-4 h-4 shrink-0" />
                ¿Necesitas una pista de la lectura?
              </button>
            ) : (
              <div className="p-3 sm:p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-amber-200 text-xs leading-relaxed flex items-start gap-2.5">
                <HelpCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Pista pedagógica: </span>
                  {currentQuestion.hint}
                </div>
              </div>
            )}
          </div>

          {/* Options List */}
          <div className="space-y-2.5 sm:space-y-3">
            {currentQuestion.options.map((option) => {
              const isSelected = selectedOptionId === option.id;

              return (
                <button
                  key={option.id}
                  disabled={showExplanation}
                  onClick={() => handleSelectOption(option.id)}
                  className={`w-full p-3.5 sm:p-4 rounded-xl border text-left transition-all flex items-center justify-between min-h-[48px] ${
                    showExplanation
                      ? option.isCorrect
                        ? 'bg-emerald-950/80 border-emerald-500 text-emerald-200 font-medium'
                        : isSelected
                        ? 'bg-rose-950/80 border-rose-500 text-rose-200'
                        : 'bg-slate-900/50 border-slate-800/80 text-slate-500 opacity-60'
                      : isSelected
                      ? 'bg-cyan-950/80 border-cyan-500 text-white shadow-lg ring-1 ring-cyan-500/40'
                      : 'bg-slate-800/50 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`w-7 h-7 rounded-lg flex items-center justify-center font-mono text-xs font-bold uppercase shrink-0 ${
                        isSelected ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {option.id}
                    </span>
                    <span className="text-xs sm:text-sm leading-snug">{option.text}</span>
                  </div>

                  {showExplanation && option.isCorrect && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 ml-2" />
                  )}
                  {showExplanation && isSelected && !option.isCorrect && (
                    <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 ml-2" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation Banner & Action Controls */}
          {showExplanation && (
            <div
              className={`p-4 rounded-xl border space-y-3 animate-fade-in ${
                isCorrectAnswer
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                  : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm">
                {isCorrectAnswer ? (
                  <>
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>¡Respuesta Correcta! Excelente análisis.</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-rose-400" />
                    <span>Respuesta Incorrecta. Debes reiniciar la misión para asegurar tu aprendizaje.</span>
                  </>
                )}
              </div>

              <p className="text-xs leading-relaxed text-slate-200">{currentQuestion.explanation}</p>

              <div className="pt-2 flex justify-end">
                {isCorrectAnswer ? (
                  currentQuestionIndex < activeQuestions.length - 1 ? (
                    <button
                      onClick={handleNextQuestion}
                      className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md transition-all"
                    >
                      Siguiente Pregunta
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <div className="flex flex-col sm:flex-row items-center gap-3">
                      <span className="text-xs font-bold text-emerald-400">
                        ¡Misión {activeMission.id} Completada con éxito!
                      </span>
                      {activeMissionIndex < MISSIONS.length - 1 ? (
                        <button
                          onClick={() => handleSelectMission(activeMissionIndex + 1)}
                          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-all"
                        >
                          Ir a la Misión {activeMissionIndex + 2}
                          <ArrowRight className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          onClick={onGoToRubric}
                          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs shadow-md transition-all"
                        >
                          Ver mi Calificación y Rúbrica
                          <Trophy className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  )
                ) : (
                  <button
                    onClick={handleRestartMission}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md transition-all"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Reiniciar Misión {activeMission.id} (Intento #{localAttempts[activeMissionIndex] + 1})
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Confirm answer button if option selected but not submitted */}
          {!showExplanation && (
            <div className="flex justify-end pt-2">
              <button
                disabled={!selectedOptionId}
                onClick={handleSubmitAnswer}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-xs transition-all shadow-lg ${
                  selectedOptionId
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/20 transform hover:-translate-y-0.5'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                Confirmar Respuesta
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Completion Banner if All 4 Missions done */}
      {allMissionsCompleted && (
        <div className="bg-gradient-to-r from-emerald-950 via-teal-950 to-slate-900 border border-emerald-500/40 rounded-2xl p-6 text-center shadow-2xl space-y-3">
          <div className="inline-flex p-3 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 mb-1">
            <Trophy className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white">¡Felicidades! Has completado las 4 Misiones Históricas</h3>
          <p className="text-xs text-slate-300 max-w-xl mx-auto">
            Has demostrado tu conocimiento de la Prehistoria, los Filósofos Griegos, la Alquimia y la Revolución Científica Moderna. Revisa tu lista de cotejo para obtener tu calificación de 10 puntos y tu evidencia digital.
          </p>
          <button
            onClick={onGoToRubric}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 transition-all"
          >
            Ver Rúbrica de Evaluación y Retroalimentación IA
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';
import { READING_STAGES } from '../data/readingContent';
import { ReadingStage } from '../types';
import { Flame, Atom, Sparkles, Zap, FlaskConical, CheckCircle2, Search, ArrowRight, BookOpenCheck } from 'lucide-react';

interface ReadingModuleProps {
  reviewedReading: boolean;
  understoodReading: boolean;
  onConfirmReading: () => void;
  onGoToMissions: () => void;
}

export const ReadingModule: React.FC<ReadingModuleProps> = ({
  reviewedReading,
  understoodReading,
  onConfirmReading,
  onGoToMissions,
}) => {
  const [activeStageId, setActiveStageId] = useState<string>('prehistoria');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const activeStage = READING_STAGES.find((s) => s.id === activeStageId) || READING_STAGES[0];

  const getStageIcon = (iconName: string, className = 'w-5 h-5') => {
    switch (iconName) {
      case 'Flame':
        return <Flame className={className} />;
      case 'Atom':
        return <Atom className={className} />;
      case 'Sparkles':
        return <Sparkles className={className} />;
      case 'Zap':
        return <Zap className={className} />;
      case 'FlaskConical':
        return <FlaskConical className={className} />;
      default:
        return <Flame className={className} />;
    }
  };

  const filteredStages = READING_STAGES.filter(
    (stage) =>
      stage.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stage.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stage.keyConcepts.some((c) => c.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      {/* Top Banner Notice */}
      <div className="bg-indigo-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 uppercase tracking-widest">
              Paso 1 de la Actividad
            </span>
            <span className="text-xs text-indigo-200 font-medium">Requisito para Rúbrica (+2 Puntos)</span>
          </div>
          <h2 className="text-2xl font-bold text-white tracking-tight">
            Lectura Guiada: Antecedentes Históricos de la Química
          </h2>
          <p className="text-sm text-indigo-100 leading-relaxed">
            Lee con atención las 5 etapas históricas. Al finalizar la lectura, presiona el botón de confirmación
            para registrar los puntos correspondientes en la lista de cotejo de evaluación.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto shrink-0">
          {!reviewedReading ? (
            <button
              onClick={onConfirmReading}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-white hover:bg-slate-100 text-indigo-900 font-bold text-xs shadow-md transition-all"
            >
              <BookOpenCheck className="w-4 h-4 text-indigo-700" />
              Marcar Lectura Revisa (+2 pts)
            </button>
          ) : (
            <div className="w-full sm:w-auto flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-200 font-bold text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>¡Lectura Confirmada! (+2 Pts)</span>
            </div>
          )}

          <button
            onClick={onGoToMissions}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md transition-all"
          >
            Ir a las Misiones
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stage Selector Timeline Bar */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
            <span>Línea del Tiempo Histórica (5 Etapas)</span>
          </h3>
          {/* Search bar */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Buscar concepto o filósofo..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 text-slate-700 text-xs rounded-2xl pl-9 pr-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
          {filteredStages.map((stage) => {
            const isActive = stage.id === activeStageId;
            return (
              <button
                key={stage.id}
                onClick={() => setActiveStageId(stage.id)}
                className={`flex flex-col items-start p-4 rounded-2xl border text-left transition-all ${
                  isActive
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-md'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <span className={`text-[10px] font-bold uppercase tracking-wider ${isActive ? 'text-indigo-200' : 'text-indigo-600'}`}>
                    Etapa {stage.number}
                  </span>
                  <div className={isActive ? 'text-white' : 'text-indigo-600'}>
                    {getStageIcon(stage.icon, 'w-4 h-4')}
                  </div>
                </div>
                <h4 className="text-xs font-bold line-clamp-1 mt-1">{stage.title}</h4>
                <p className={`text-[10px] mt-0.5 ${isActive ? 'text-indigo-100' : 'text-slate-400'}`}>{stage.period}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area for Selected Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Text Article (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-8 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                {getStageIcon(activeStage.icon, 'w-6 h-6')}
              </div>
              <div>
                <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest">
                  Etapa {activeStage.number} de 5 · {activeStage.period}
                </span>
                <h3 className="text-2xl font-bold text-slate-800 mt-0.5">{activeStage.title}</h3>
              </div>
            </div>
          </div>

          {/* Paragraphs */}
          <div className="space-y-3.5 text-slate-700 text-sm leading-relaxed">
            {activeStage.fullText.map((paragraph, index) => (
              <p key={index} className="p-4 rounded-2xl bg-slate-50 border border-slate-100 text-slate-700">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Key Concepts Tags */}
          <div className="border-t border-slate-100 pt-5">
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-3">
              Conceptos Clave de la Lectura
            </h4>
            <div className="flex flex-wrap gap-2">
              {activeStage.keyConcepts.map((concept, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-bold"
                >
                  {concept}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar Cards: Key Figures & Inventions (1 col) */}
        <div className="space-y-6">
          {/* Key Figures */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-3 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
              Personajes y Filósofos Clave
            </h3>

            <div className="space-y-3">
              {activeStage.keyFigures.map((figure, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1 hover:border-slate-200 transition-all"
                >
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-indigo-700">{figure.name}</h4>
                    <span className="text-[10px] text-slate-500 font-mono bg-white px-2 py-0.5 rounded-md border border-slate-200">
                      {figure.period}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-snug pt-0.5">{figure.contribution}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Inventions & Lab Techniques */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-3 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              Técnicas, Materiales e Inventos
            </h3>

            <ul className="space-y-2">
              {activeStage.inventionsAndTechniques.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

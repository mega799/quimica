import React, { useState, useEffect } from 'react';
import { StudentInfo } from './types';
import { Header } from './components/Header';
import { ReadingModule } from './components/ReadingModule';
import { MissionGameModule } from './components/MissionGameModule';
import { RubricTracker } from './components/RubricTracker';
import { EvidenceVoucher } from './components/EvidenceVoucher';

export default function App() {
  const [student, setStudent] = useState<StudentInfo>({
    name: 'Estudiante 1º Prepa',
    group: '1ºA',
    date: new Date().toLocaleDateString('es-MX'),
    startTime: new Date().toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' }),
  });

  const [activeTab, setActiveTab] = useState<'reading' | 'missions' | 'rubric' | 'evidence'>('reading');

  // Rubric State Variables
  const [onTime, setOnTime] = useState<boolean>(true);
  const [reviewedReading, setReviewedReading] = useState<boolean>(false);
  const [understoodReading, setUnderstoodReading] = useState<boolean>(false);
  const [completedMissions, setCompletedMissions] = useState<boolean[]>([false, false, false, false]);
  const [attemptsPerMission, setAttemptsPerMission] = useState<number[]>([1, 1, 1, 1]);
  const [evidenceCaptured, setEvidenceCaptured] = useState<boolean>(true);

  // Timer state
  const [secondsElapsed, setSecondsElapsed] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatElapsedTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const remainingSecs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  const handleConfirmReading = () => {
    setReviewedReading(true);
    setUnderstoodReading(true);
  };

  const handleMissionComplete = (missionIndex: number, attemptsCount: number) => {
    setCompletedMissions((prev) => {
      const next = [...prev];
      next[missionIndex] = true;
      return next;
    });

    setAttemptsPerMission((prev) => {
      const next = [...prev];
      next[missionIndex] = attemptsCount;
      return next;
    });
  };

  // Rubric score calculation
  const completedMissionsCount = completedMissions.filter(Boolean).length;
  const maxAttempts = Math.max(...attemptsPerMission, 0);
  const completedIn3AttemptsOrLess = completedMissionsCount === 4 && maxAttempts <= 3;

  const totalScore =
    (onTime ? 1 : 0) +
    (reviewedReading ? 1 : 0) +
    (understoodReading ? 1 : 0) +
    (completedIn3AttemptsOrLess ? 2 : 0) +
    completedMissionsCount +
    (evidenceCaptured ? 1 : 0);

  return (
    <div className="min-h-screen bg-[#F1F5F9] text-slate-800 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header Bar */}
      <Header
        student={student}
        setStudent={setStudent}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalScore={totalScore}
        completedMissionsCount={completedMissionsCount}
        elapsedTimeString={formatElapsedTime(secondsElapsed)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'reading' && (
          <ReadingModule
            reviewedReading={reviewedReading}
            understoodReading={understoodReading}
            onConfirmReading={handleConfirmReading}
            onGoToMissions={() => setActiveTab('missions')}
          />
        )}

        {activeTab === 'missions' && (
          <MissionGameModule
            completedMissions={completedMissions}
            attemptsPerMission={attemptsPerMission}
            onMissionComplete={handleMissionComplete}
            onGoToRubric={() => setActiveTab('rubric')}
          />
        )}

        {activeTab === 'rubric' && (
          <RubricTracker
            student={student}
            reviewedReading={reviewedReading}
            understoodReading={understoodReading}
            onTime={onTime}
            completedMissions={completedMissions}
            attemptsPerMission={attemptsPerMission}
            evidenceCaptured={evidenceCaptured}
            onToggleOnTime={() => setOnTime(!onTime)}
            onToggleReviewedReading={() => setReviewedReading(!reviewedReading)}
            onToggleUnderstoodReading={() => setUnderstoodReading(!understoodReading)}
            onToggleEvidenceCaptured={() => setEvidenceCaptured(!evidenceCaptured)}
            onGoToEvidence={() => setActiveTab('evidence')}
          />
        )}

        {activeTab === 'evidence' && (
          <EvidenceVoucher
            student={student}
            reviewedReading={reviewedReading}
            understoodReading={understoodReading}
            onTime={onTime}
            completedMissions={completedMissions}
            attemptsPerMission={attemptsPerMission}
            evidenceCaptured={evidenceCaptured}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-5 text-center text-xs text-slate-500 print:hidden mt-8">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="font-medium text-slate-600">Benemérita Universidad Autónoma de Aguascalientes · CEM · Química Inorgánica · Actividad 2</span>
          <span className="font-mono text-slate-400">Plataforma Educativa Interactiva</span>
        </div>
      </footer>
    </div>
  );
}

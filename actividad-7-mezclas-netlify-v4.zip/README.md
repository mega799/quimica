# Actividad 7 · Soluciones, suspensiones y coloides

Aplicación estática lista para publicar en Netlify. Para usarla, sube esta carpeta completa o el archivo ZIP a Netlify.

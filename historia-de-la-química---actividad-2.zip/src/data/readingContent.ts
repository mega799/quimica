import { ReadingStage } from '../types';

export const READING_STAGES: ReadingStage[] = [
  {
    id: 'prehistoria',
    number: 1,
    title: 'Prehistoria y la Antigüedad',
    period: '100,000 a.C. - 600 a.C.',
    icon: 'Flame',
    color: 'amber',
    summary: 'Surgimiento de la química con el descubrimiento del fuego y la manipulación de metales como oro, bronce y hierro para cubrir necesidades básicas.',
    fullText: [
      'La prehistoria se inició con las primeras actividades humanas y terminó con los manuscritos primitivos. El ser humano cubrió sus necesidades básicas comiendo carne cruda y plantas silvestres, utilizando las piedras como herramientas para cortar y defenderse, teniendo como vivienda las cavernas.',
      'Puede decirse que la Química surge en la etapa de la prehistoria y antigüedad (desde 100,000 a. C. hasta 600 años a.C.); en el momento que los homínidos descubren el fuego y lo empiezan a utilizar en su beneficio al cocinar los alimentos y para el manejo de los metales (lo que llamamos ahora metalurgia).',
      'Pasando por la edad del oro (5,000 a.C.), la edad del bronce -cobre con estaño- (4,000 a.C.), la edad del hierro (1,200 a. C) y la época de los egipcios (3,000 a. C. hasta 400 a. C.). A lo largo de esta etapa encontramos el inicio del desarrollo de la producción de alfarería, cerámicas, aceites, jabones, bebidas fermentadas, producción de ungüentos y medicamentos.',
      'El descubrimiento posterior del hierro le permitió construir mejores armas de guerra que lograron perfeccionar al descubrir una nueva aleación: el acero, que obtuvieron mezclando al fuego hierro y carbón de leña. En esta época se le daba un sentido mágico y místico a la naturaleza y a sus cambios.',
      'Por lo tanto, el inicio de la química en la prehistoria se da con la manipulación de elementos metálicos y su interacción con el fuego.'
    ],
    keyConcepts: [
      'Descubrimiento del fuego',
      'Metalurgia y aleaciones (Bronce y Acero)',
      'Edad del Oro, Bronce y Hierro',
      'Producción de cerámicas, jabones y medicamentos',
      'Sentido mágico y místico de la naturaleza'
    ],
    keyFigures: [
      {
        name: 'Homínidos primitivos',
        period: '100,000 a.C.',
        contribution: 'Descubrimiento y control del fuego para cocinar y procesar materiales.'
      },
      {
        name: 'Cultura Egipcia',
        period: '3,000 - 400 a.C.',
        contribution: 'Pioneros en embalsamamiento, elaboración de jabones, aceites y cerámicas.'
      }
    ],
    inventionsAndTechniques: [
      'Uso del fuego',
      'Fundición de metales',
      'Aleación de Acero (Hierro + Carbón)',
      'Aleación de Bronce (Cobre + Estaño)',
      'Alfarería y fermentación'
    ]
  },
  {
    id: 'griegos',
    number: 2,
    title: 'Los Griegos y la Filosofía de la Materia',
    period: '600 a.C. - 300 a.C.',
    icon: 'Atom',
    color: 'blue',
    summary: 'Surgimiento de explicaciones filosóficas sobre la materia: la teoría de los 4 elementos y el concepto original del átomo.',
    fullText: [
      'En la época antigua, el desarrollo de grandes civilizaciones como la egipcia, persa y mesopotámica permitió conocer técnicas para elaborar vidrio, barnices, perfumes, jabones, bálsamos, cosméticos, medicamentos y vino.',
      'Muchos colorantes eran sales tóxicas que ignoraban; por ejemplo, el sulfuro de mercurio (cinabrio) servía para pintarse los labios de rojo sin saber el riesgo de envenenamiento lento. También utilizaban arsénico y antimonio.',
      'En la etapa de los grandes filósofos griegos surgieron explicaciones filosóficas acerca de la materia. Nace la teoría de los 4 elementos: Agua (Tales de Mileto, 600 a.C.), Aire (Anaxímenes, 500 a.C.), Fuego (Heráclito, 400 a.C.) y Tierra (Empédocles, 400 a.C.).',
      'Dicha teoría fue aceptada, defendida y divulgada por Aristóteles (300 a.C.), quien agregó cuatro cualidades básicas: caliente, frío, húmedo y seco (p. ej. frío + húmedo = agua; caliente + húmedo = aire). Debido a la gran influencia de Aristóteles, esta teoría se mantuvo durante casi 2,000 años.',
      'Por otro lado, Leucipo y su discípulo Demócrito (siglos V y IV a.C.) plantearon que la materia podía dividirse hasta llegar a una partícula límite, eterna e indivisible llamada «átomo» (a = sin; tomo = división).'
    ],
    keyConcepts: [
      'Teoría de los 4 Elementos (Agua, Aire, Fuego, Tierra)',
      'Cuatro Cualidades (Caliente, Frío, Húmedo, Seco)',
      'Concepto de Átomo (Partícula indivisible)',
      'Uso de pigmentos antiguos (Cinabrio / Sulfuro de Mercurio)'
    ],
    keyFigures: [
      {
        name: 'Tales de Mileto (640-560 a.C.)',
        period: '600 a.C.',
        contribution: 'Propuso el Agua como elemento primordial ("sin agua no hay vida").'
      },
      {
        name: 'Heráclito (533-473 a.C.)',
        period: '400 a.C.',
        contribution: 'Planteó el Fuego y el flujo constante de la materia.'
      },
      {
        name: 'Empédocles y Anaxímenes',
        period: '500-400 a.C.',
        contribution: 'Propusieron la Tierra y el Aire respectivamente.'
      },
      {
        name: 'Aristóteles',
        period: '300 a.C.',
        contribution: 'Divulgó la teoría de los 4 elementos y 4 cualidades por 20 siglos.'
      },
      {
        name: 'Leucipo y Demócrito',
        period: 'Siglos V y IV a.C.',
        contribution: 'Creadores del concepto filosófico de Átomo (indivisible).'
      }
    ],
    inventionsAndTechniques: [
      'Elaboración de vidrio y cosméticos',
      'Uso de cinabrio para labiales',
      'Teorías filosóficas de la materia'
    ]
  },
  {
    id: 'alquimia',
    number: 3,
    title: 'La Alquimia',
    period: '300 a.C. - 1600 d.C.',
    icon: 'Sparkles',
    color: 'purple',
    summary: 'Mezcla de técnica, misticismo y filosofía. Búsqueda de la piedra filosofal y el elixir de la vida, sentando las bases del laboratorio químico.',
    fullText: [
      'En el siglo I a.C. surgió en India, China y Grecia un conocimiento de los materiales mezclando técnica, misticismo, magia, astrología y filosofía denominado alquimia, con su máximo apogeo en la Edad Media.',
      'Combinó saberes egipcios (momificación con carbonatos y nitratos, vidrio, papel) e ideas griegas. Los alquimistas eran famosos por buscar dos grandes secretos: la Piedra Filosofal (para convertir metales en oro) y el Elixir de la Vida (infusión para la inmortalidad).',
      'Personajes destacados: Zósimo de Panópolis (fundó escuela en Alejandría -300 d.C.), Hermes Trimegisto ("tres veces grande", figura legendaria) y el árabe Geber, quien clasificó las sustancias en: espíritus (volátiles como alcohol), cuerpos metálicos (metales) y cuerpos (sólidos no volátiles).',
      'Los alquimistas desarrollaron el laboratorio químico aplicando destilación, calcinación, sublimación, cristalización y metalurgia. Inventaron el "baño de María", el alambique y el agua regia (mezcla de ácidos fuerte).',
      'Paracelso (1493-1541) fue el gran precursor de la química farmacéutica o Iatroquímica, aplicando remedios químicos para curar enfermedades.'
    ],
    keyConcepts: [
      'Piedra Filosofal y Elixir de la Vida',
      'Clasificación de Geber (Espíritus, Metales y Cuerpos)',
      'Técnicas de laboratorio (Destilación, Baño María, Alambique)',
      'Iatroquímica o Química Farmacéutica (Paracelso)'
    ],
    keyFigures: [
      {
        name: 'Zósimo de Panópolis',
        period: '300 d.C.',
        contribution: 'Fundador de la escuela de alquimia en Alejandría.'
      },
      {
        name: 'Geber (Jabir ibn Hayyan)',
        period: 'Siglo VIII d.C.',
        contribution: 'Clasificó sustancias en espíritus, metales y sólidos no volátiles.'
      },
      {
        name: 'Paracelso (1493-1541)',
        period: 'Siglo XVI',
        contribution: 'Precursor de la química farmacéutica (Iatroquímica).'
      }
    ],
    inventionsAndTechniques: [
      'Alambique y Baño de María',
      'Agua Regia (mezcla de ácidos)',
      'Destilación, Sublimación y Cristalización'
    ]
  },
  {
    id: 'flogisto',
    number: 4,
    title: 'La Etapa del Flogisto',
    period: '1700 - 1777 d.C.',
    icon: 'Zap',
    color: 'orange',
    summary: 'Teoría que intentaba explicar la combustión mediante un "principio inflamable" llamado flogisto que se liberaba al arder.',
    fullText: [
      'En el siglo XVII y XVIII (1700-1777), desarrollada por Johann Becher y Georg Stahl, se propone la Teoría del Flogisto.',
      'Proponían que todas las sustancias combustibles contenían un "principio inflamable" o fluido misterioso llamado flogisto.',
      'Según esta teoría, cuando un objeto ardía, el flogisto se desprendía hacia el aire acompañado de luz y calor.',
      'Postulaban por ejemplo que la madera contenía gran cantidad de flogisto, pero las cenizas resultantes carecían de él, razón por la cual las cenizas ya no podían volver a arder.'
    ],
    keyConcepts: [
      'Principio Inflamable (Flogisto)',
      'Explicación de la combustión previa a Lavoisier',
      'Pérdida de flogisto en cenizas'
    ],
    keyFigures: [
      {
        name: 'Johann Becher y Georg Stahl',
        period: '1700 - 1777',
        contribution: 'Desarrollaron la teoría del flogisto para explicar el fuego.'
      }
    ],
    inventionsAndTechniques: [
      'Experimentos de combustión en recipientes cerrados',
      'Análisis cualitativo del fuego'
    ]
  },
  {
    id: 'moderna',
    number: 5,
    title: 'La Química Moderna',
    period: '1777 d.C. - Actualidad',
    icon: 'FlaskConical',
    color: 'emerald',
    summary: 'Nacimiento de la química cuantitativa y científica gracias a Lavoisier, el descubrimiento del oxígeno y la Ley de Conservación de la Materia.',
    fullText: [
      'La Química Moderna surge a partir del trabajo de Antoine Laurent Lavoisier al destruir la teoría del flogisto. Demuestra experimentalmente que las sustancias se queman al combinarse con el oxígeno del aire.',
      'Por sus enormes aportaciones, Lavoisier es considerado el Padre de la Química Moderna. En 1785 demuestra la Ley de la Conservación de la Materia ("la materia no se crea ni se destruye, solo se transforma") y en 1789 publica su Tratado Elemental de Química, definiendo lo que es un elemento químico.',
      'Otros científicos clave:',
      '• Juan Bautista Van Helmont (1577-1644): mediciones precisas del crecimiento de plantas.',
      '• Robert Boyle (1627-1691): estudio de gases y método cualitativo comprobable.',
      '• Joseph Priestley (1733-1804): descubrió el oxígeno necesario para la combustión.',
      '• John Dalton (Siglo XIX): formuló la primera teoría atómica científica.',
      'Hoy la química es una ciencia interdisciplinaria ligada a la física, medicina, biología y tecnología, permitiendo el desarrollo de medicamentos, materiales y avances globales.'
    ],
    keyConcepts: [
      'Destrucción del Flogisto por Lavoisier',
      'Ley de la Conservación de la Materia (1785)',
      'Tratado Elemental de Química (1789)',
      'Descubrimiento del Oxígeno (Priestley)',
      'Primera Teoría Atómica Científica (Dalton)'
    ],
    keyFigures: [
      {
        name: 'Antoine Laurent Lavoisier (1743-1794)',
        period: 'Siglo XVIII',
        contribution: 'Padre de la Química Moderna. Método cuantitativo y Ley de Conservación de la Materia.'
      },
      {
        name: 'Joseph Priestley (1733-1804)',
        period: 'Siglo XVIII',
        contribution: 'Descubrió el oxígeno.'
      },
      {
        name: 'Robert Boyle (1627-1691)',
        period: 'Siglo XVII',
        contribution: 'Estudio de gases y método cualitativo.'
      },
      {
        name: 'John Dalton',
        period: 'Siglo XIX',
        contribution: 'Primera teoría atómica moderna.'
      }
    ],
    inventionsAndTechniques: [
      'Balanza de precisión y método cuantitativo',
      'Tabla elemental de sustancias simples',
      'Teoría atómica moderna y química interdisciplinaria'
    ]
  }
];

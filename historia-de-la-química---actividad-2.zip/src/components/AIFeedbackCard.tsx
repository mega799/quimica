import React, { useState } from 'react';
import { AIFeedbackResponse, StudentInfo } from '../types';
import { Sparkles, Bot, CheckCircle2, AlertTriangle, Lightbulb, RefreshCw, MessageSquareQuote } from 'lucide-react';

interface AIFeedbackCardProps {
  student: StudentInfo;
  totalScore: number;
  completedMissionsCount: number;
  attemptsPerMission: number[];
  reviewedReading: boolean;
  understoodReading: boolean;
  onTime: boolean;
}

export const AIFeedbackCard: React.FC<AIFeedbackCardProps> = ({
  student,
  totalScore,
  completedMissionsCount,
  attemptsPerMission,
  reviewedReading,
  understoodReading,
  onTime,
}) => {
  const [feedback, setFeedback] = useState<AIFeedbackResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fetchAIFeedback = async () => {
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: student.name || 'Alumno de 1º de Preparatoria',
          group: student.group,
          totalScore,
          missionsCompleted: completedMissionsCount,
          attemptsPerMission,
          readAssignedText: reviewedReading,
          comprehendedText: understoodReading,
          onTime,
        }),
      });

      if (!res.ok) {
        throw new Error('Error al conectar con el servidor de IA.');
      }

      const data: AIFeedbackResponse = await res.json();
      setFeedback(data);
    } catch (err: any) {
      console.error(err);
      setError('No se pudo generar la retroalimentación en este momento. Intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-purple-500/30 rounded-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background Subtle Gradient */}
      <div className="absolute -top-24 -right-24 w-60 h-60 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 p-0.5 shadow-lg shadow-purple-500/20">
            <div className="w-full h-full bg-slate-900 rounded-[14px] flex items-center justify-center">
              <Bot className="w-6 h-6 text-purple-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Mentor de Química Gemini AI
              </span>
            </div>
            <h3 className="text-lg font-bold text-white">Retroalimentación Personalizada con IA</h3>
          </div>
        </div>

        <button
          onClick={fetchAIFeedback}
          disabled={loading}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/25 transition-all disabled:opacity-50"
        >
          {loading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              Generando Análisis...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              {feedback ? 'Actualizar Retroalimentación' : 'Generar Retroalimentación IA'}
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {!feedback && !loading && !error && (
        <div className="text-center py-8 space-y-3 bg-slate-800/30 rounded-xl border border-slate-800 p-6">
          <MessageSquareQuote className="w-10 h-10 text-purple-400/60 mx-auto" />
          <p className="text-xs text-slate-300 max-w-md mx-auto">
            Presiona el botón de arriba para recibir un informe pedagógico detallado creado por la IA,
            analizando tus fortalezas en la historia de la química y recomendaciones de estudio.
          </p>
        </div>
      )}

      {feedback && (
        <div className="space-y-5 animate-fade-in">
          {/* Summary Quote Box */}
          <div className="p-4 rounded-xl bg-purple-950/40 border border-purple-500/30 text-purple-100 text-xs sm:text-sm leading-relaxed flex items-start gap-3">
            <MessageSquareQuote className="w-6 h-6 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-purple-300">Resumen del Docente Virtual: </span>
              {feedback.summary}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Strengths */}
            <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-2">
              <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                Fortalezas Demostradas
              </h4>
              <ul className="space-y-1.5">
                {feedback.strengths.map((s, idx) => (
                  <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Areas to Review */}
            <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-2">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Lightbulb className="w-4 h-4" />
                Áreas de Repaso
              </h4>
              <ul className="space-y-1.5">
                {feedback.areasToReview.map((a, idx) => (
                  <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>{a}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Pedagogical Note */}
          <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 text-slate-200 text-xs italic border-l-4 border-l-indigo-500">
            "{feedback.pedagogicalNote}"
          </div>
        </div>
      )}
    </div>
  );
};

const $ = (id) => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);
$('date').value = today; $('peerDate').value = today;
const ACTIVITY_ID_KEY = 'actividad4_unique_id_v8';
function generateActivityId(){
  const d = new Date();
  const pad = n => String(n).padStart(2,'0');
  const stamp = `${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
  const rand = Math.random().toString(36).slice(2,6).toUpperCase();
  return `ACT4-${stamp}-${rand}`;
}
let uniqueId = localStorage.getItem(ACTIVITY_ID_KEY);
if(!uniqueId){ uniqueId = generateActivityId(); localStorage.setItem(ACTIVITY_ID_KEY, uniqueId); }

const STATES = ['Sólido','Líquido','Gaseoso','Plasma'];
const part1 = [
  ['Forma constante','Sólido'],['Partículas cargadas','Plasma'],['Volumen indefinido','Gaseoso|Plasma'],
  ['Compresibles','Gaseoso'],['Partículas independientes','Gaseoso'],['Forma indefinida','Líquido|Gaseoso|Plasma'],
  ['Partículas bajo influencia de campo magnético','Plasma'],['Volumen constante','Sólido|Líquido'],
  ['Partículas fuertemente unidas','Sólido'],['Se alcanza a temperaturas elevadas','Plasma'],
  ['Expansibles','Gaseoso'],['Partículas débilmente unidas','Líquido']
];
const substances = [
  ['Cubo de hielo','Sólido'],['Agua embotellada','Líquido'],['Vapor de agua de una olla hirviendo','Gaseoso'],
  ['Barra de aluminio','Sólido'],['Gas contenido en un globo inflado','Gaseoso'],['Mercurio de un termómetro','Líquido'],
  ['Lámpara fluorescente encendida','Plasma'],['Sal de mesa','Sólido'],['Perfume al ser rociado en el ambiente','Gaseoso'],['Lava volcánica en erupción','Líquido']
];
const words = ['','solidificación','sublimación inversa','ebullición','gaseoso','líquido','sólido','sublimación','fusión','condensación','temperatura'];
const p3answers = ['temperatura','ebullición','líquido','gaseoso','condensación','líquido','solidificación','líquido','sólido','gaseoso','sublimación'];
const properties = ['Oxidación','Reactividad','Solubilidad','Combustión','Densidad','Masa','Volumen'];
const p4cases = [
  ['Caso 1','Un clavo de hierro queda varios días al aire libre y aparecen manchas rojizas.','Oxidación','Química'],
  ['Caso 2','Una tira de magnesio arde intensamente cuando se acerca a una flama.','Combustión','Química'],
  ['Caso 3','Una tableta efervescente libera burbujas al entrar en contacto con agua.','Reactividad','Química'],
  ['Caso 4','Una cucharada de sal desaparece al mezclarse con agua.','Solubilidad','Física'],
  ['Caso 5','Dos objetos tienen el mismo tamaño, pero uno pesa mucho más que el otro.','Densidad','Física'],
  ['Caso 6','Una mochila se coloca en una báscula para conocer cuánta materia contiene.','Masa','Física'],
  ['Caso 7','Un vaso medidor indica el espacio que ocupa una muestra de líquido.','Volumen','Física']
];
const life = [
  ['Agua hirviendo en una olla','Punto de ebullición','Intensiva','Física'],
  ['Una barra de hierro oxidándose al aire','Oxidación','Intensiva','Química'],
  ['Un litro de leche en un envase','Volumen','Extensiva','Física'],
  ['El aroma de un perfume en el aire','Olor','Intensiva','Física'],
  ['Un bloque de hielo derritiéndose','Punto de fusión','Intensiva','Física'],
  ['Combustión de gasolina en un motor','Combustibilidad','Intensiva','Química']
];
const rubric = [
  'Entregó la actividad completa, respondiendo todas las partes solicitadas.',
  'Identificó correctamente los estados de agregación de la materia.',
  'Justificó adecuadamente las respuestas utilizando las propiedades de la materia.',
  'Identificó correctamente los cambios de estado en el ejercicio correspondiente.',
  'Identificó correctamente propiedades de la materia en situaciones concretas.',
  'Clasificó correctamente las propiedades como intensivas o extensivas, y como físicas o químicas.',
  'Presentó respuestas claras, ordenadas y con buena ortografía.',
  'Mostró responsabilidad y cuidado en la elaboración de la actividad.'
];
function opt(list, selected='') {return list.map(v=>`<option ${v===selected?'selected':''}>${v}</option>`).join('')}
function normalize(s){return (s||'').toString().trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')}
function build(){
  $('part1').innerHTML = part1.map((q,i)=>`<div class="q"><div class="q-title">${i+1}. ${q[0]}</div><select data-key="${q[1]}" id="p1_${i}"><option value="">Selecciona estado</option>${opt(STATES)}</select></div>`).join('');
  $('part2').innerHTML = substances.map((s,i)=>`<div class="substance"><h3>${i+1}. ${s[0]}</h3><select data-key="${s[1]}" id="p2_${i}"><option value="">Estado de agregación</option>${opt(STATES)}</select><textarea id="p2j_${i}" rows="2" placeholder="Justifica brevemente tu respuesta"></textarea></div>`).join('');
  let blanks = 0;
  const blank = () => `<select class="inline-select" data-key="${p3answers[blanks]}" id="p3_${blanks++}">${words.map(w=>`<option>${w}</option>`).join('')}</select>`;
  $('part3').innerHTML = `En la cocina de una casa, al calentar agua en una olla, esta comienza a aumentar su ${blank()} hasta llegar al punto de ${blank()}, donde pasa del estado ${blank()} al estado ${blank()}, formando vapor que se dispersa en el aire.<br><br>Cuando este vapor toca una superficie fría, ocurre la ${blank()}, transformándose nuevamente en estado ${blank()}, formando pequeñas gotas de agua.<br><br>Si el agua se deja en el congelador, ocurre la ${blank()}, donde pasa de estado ${blank()} a estado ${blank()}.<br><br>En condiciones muy frías, algunos sólidos pueden pasar directamente a estado ${blank()} sin pasar por el estado líquido, proceso conocido como ${blank()}.`;
  $('part4').innerHTML = p4cases.map((c,i)=>`<div class="case-card"><span class="chip">${c[0]}</span><div class="q-title">${c[1]}</div><label>Propiedad de la materia<select id="p4prop_${i}" data-key="${c[2]}"><option value="">Selecciona la propiedad</option>${opt(properties)}</select></label><label>Tipo de propiedad<select id="p4type_${i}" data-key="${c[3]}"><option value="">Selecciona el tipo</option><option>Física</option><option>Química</option></select></label></div>`).join('');
  $('part5').innerHTML = life.map((r,i)=>`<div class="life"><h3>${i+1}. ${r[0]}</h3><input id="p5prop_${i}" data-key="${r[1]}" type="text" placeholder="Propiedad observada"><div class="grid two"><select id="p5ie_${i}" data-key="${r[2]}"><option value="">Intensiva / Extensiva</option><option>Intensiva</option><option>Extensiva</option></select><select id="p5fq_${i}" data-key="${r[3]}"><option value="">Física / Química</option><option>Física</option><option>Química</option></select></div></div>`).join('');
  $('rubric').innerHTML = rubric.map((r,i)=>`<div class="rubric-item"><strong>${i+1}. ${r}</strong><div class="rubric-scale"><label><input type="radio" name="rub_${i}" value="1">Sí cumple</label><label><input type="radio" name="rub_${i}" value="0.5">Cumple parcialmente</label><label><input type="radio" name="rub_${i}" value="0">No cumple</label></div></div>`).join('');
}
build();
if($('uniqueId')) $('uniqueId').value = uniqueId;
if($('uniqueIdLabel')) $('uniqueIdLabel').textContent = uniqueId;

const panels = [...document.querySelectorAll('.panel')]; const tabs = [...document.querySelectorAll('.tab')]; let current = 0;
function show(i){current=Math.max(0,Math.min(i,panels.length-1)); panels.forEach((p,n)=>p.classList.toggle('active',n===current)); tabs.forEach((t,n)=>t.classList.toggle('active',n===current)); window.scrollTo({top:0,behavior:'smooth'});}
tabs.forEach((t,i)=>t.addEventListener('click',()=>show(i))); $('prevBtn').onclick=()=>show(current-1); $('nextBtn').onclick=()=>show(current+1);
$('isPeer').addEventListener('change',()=>{$('peerBox').style.display=$('isPeer').checked?'grid':'none'});
function scoreSelect(prefix, count){let ok=0; for(let i=0;i<count;i++){let el=$(`${prefix}_${i}`); const valid=(el.dataset.key||'').split('|').map(normalize); if(valid.includes(normalize(el.value))) ok++;} return ok;}
function scoreInputs(prefix, count){let ok=0; for(let i=0;i<count;i++){let el=$(`${prefix}_${i}`); if(normalize(el.value)===normalize(el.dataset.key)) ok++;} return ok;}
function scorePart4(){let ok=0; for(let i=0;i<p4cases.length;i++){ if(normalize($(`p4prop_${i}`).value)===normalize($(`p4prop_${i}`).dataset.key)) ok++; if(normalize($(`p4type_${i}`).value)===normalize($(`p4type_${i}`).dataset.key)) ok++; } return ok;}
function scoreLife(){let ok=0; for(let i=0;i<life.length;i++){ if(normalize($(`p5ie_${i}`).value)===normalize($(`p5ie_${i}`).dataset.key)) ok++; if(normalize($(`p5fq_${i}`).value)===normalize($(`p5fq_${i}`).dataset.key)) ok++; } return ok;}

function collectAnswersForPrint(){
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const rows = [];
  rows.push('<h3>Respuestas del alumno</h3>');
  rows.push('<h4>Parte 1. Estados</h4><table><tr><th>Característica</th><th>Respuesta</th></tr>' + part1.map((q,i)=>`<tr><td>${esc(q[0])}</td><td>${esc($(`p1_${i}`).value)}</td></tr>`).join('') + '</table>');
  rows.push('<h4>Parte 2. Sustancias</h4><table><tr><th>Sustancia</th><th>Estado</th><th>Justificación</th></tr>' + substances.map((q,i)=>`<tr><td>${esc(q[0])}</td><td>${esc($(`p2_${i}`).value)}</td><td>${esc($(`p2j_${i}`).value)}</td></tr>`).join('') + '</table>');
  rows.push('<h4>Parte 3. Cambios de estado</h4><table><tr><th>Espacio</th><th>Respuesta</th></tr>' + p3answers.map((q,i)=>`<tr><td>${i+1}</td><td>${esc($(`p3_${i}`).value)}</td></tr>`).join('') + '</table>');
  rows.push('<h4>Parte 4. Propiedades</h4><table><tr><th>Caso</th><th>Propiedad</th><th>Tipo</th></tr>' + p4cases.map((q,i)=>`<tr><td>${esc(q[1])}</td><td>${esc($(`p4prop_${i}`).value)}</td><td>${esc($(`p4type_${i}`).value)}</td></tr>`).join('') + '</table>');
  rows.push('<h4>Parte 5. Clasificación</h4><table><tr><th>Ejemplo</th><th>Propiedad</th><th>Intensiva/Extensiva</th><th>Física/Química</th></tr>' + life.map((q,i)=>`<tr><td>${esc(q[0])}</td><td>${esc($(`p5prop_${i}`).value)}</td><td>${esc($(`p5ie_${i}`).value)}</td><td>${esc($(`p5fq_${i}`).value)}</td></tr>`).join('') + '</table>');
  if($('isPeer').checked){
    rows.push('<h4>Coevaluación</h4><table><tr><th>Criterio</th><th>Valor</th></tr>' + rubric.map((q,i)=>{const chosen=document.querySelector(`input[name="rub_${i}"]:checked`); return `<tr><td>${esc(q)}</td><td>${esc(chosen ? chosen.parentElement.textContent.trim() : 'Sin responder')}</td></tr>`}).join('') + '</table>');
    rows.push(`<p><strong>Observaciones:</strong> ${esc($('observations').value || 'Sin observaciones')}</p>`);
  }
  return rows.join('');
}
function openPrintableReport(){
  const source = document.createElement('div');
  source.innerHTML = $('result').innerHTML;
  source.querySelectorAll('button,.ios-note').forEach(el => el.remove());
  const report = source.innerHTML + collectAnswersForPrint();
  const w = window.open('', '_blank');
  if(!w){
    alert('El navegador bloqueó la ventana emergente. Permite ventanas emergentes o usa el botón Imprimir o guardar PDF desde el navegador.');
    return;
  }
  w.document.open();
  w.document.write(`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Reporte de calificación</title><style>
    body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Arial,sans-serif;margin:16px;color:#111;line-height:1.35}h1,h2,h3,h4{page-break-after:avoid}.report-cover{border:2px solid #111;border-radius:14px;padding:12px;margin-bottom:14px}.result-grid{display:grid;grid-template-columns:1fr;gap:10px}.result-box,.breakdown div{border:1px solid #cbd5e1;border-radius:12px;padding:10px;margin:8px 0}.score{font-size:30px;font-weight:800}table{width:100%;border-collapse:collapse;margin:8px 0 18px;page-break-inside:auto}tr{page-break-inside:avoid}th,td{border:1px solid #cbd5e1;padding:7px;text-align:left;vertical-align:top;font-size:12px}button{font:inherit;border:0;border-radius:12px;background:#0f4c81;color:white;padding:12px 16px;margin:10px 0}.primary{display:none}@media print{button,.primary{display:none!important}body{margin:8mm}table{font-size:11px}.report-cover{page-break-inside:avoid}}
  </style></head><body><div class="report-cover"><h1>Reporte de calificación</h1>${report}</div><button onclick="window.print()">Imprimir o guardar PDF</button><script>window.addEventListener('load',()=>setTimeout(()=>window.print(),350));<\/script></body></html>`);
  w.document.close();
  w.focus();
}
function safePrint(){
  openPrintableReport();
}


function rubricScore(){let total=0, answered=0; for(let i=0;i<rubric.length;i++){const chosen=document.querySelector(`input[name="rub_${i}"]:checked`); if(chosen){total+=Number(chosen.value); answered++;}} return {total, answered};}
function validateDatos(){
  const missing=[]; if(!$('studentName').value.trim()) missing.push('nombre del alumno'); if(!$('grade').value) missing.push('grado'); if(!$('group').value) missing.push('grupo'); if(!$('date').value) missing.push('fecha'); if($('isPeer').checked && !$('peerName').value.trim()) missing.push('nombre de quien coevalúa');
  if(missing.length){alert('Falta capturar: '+missing.join(', ')+'.'); $('datosCard').scrollIntoView({behavior:'smooth'}); return false;} return true;
}
function lockForm(){document.querySelectorAll('#datosCard input, #activityForm input, #activityForm select, #activityForm textarea, #activityForm button').forEach(el=>{ if(el.id!=='resetBtn') el.disabled=true;}); $('app').classList.add('locked');}
$('activityForm').addEventListener('submit',(e)=>{
  e.preventDefault(); if(!validateDatos()) return;
  const rub=rubricScore();
  const now=new Date().toLocaleString('es-MX');

  const p1Score = scoreSelect('p1', part1.length);
  const p2Score = scoreSelect('p2', substances.length);
  const p3Score = scoreSelect('p3', p3answers.length);
  const p4Score = scorePart4();
  const p5Score = scoreLife();
  const totalScore = p1Score + p2Score + p3Score + p4Score + p5Score;
  const maxScore = part1.length + substances.length + p3answers.length + (p4cases.length * 2) + (life.length * 2);
  const percent = Math.round((totalScore / maxScore) * 100);
  const grade10 = ((totalScore / maxScore) * 10).toFixed(1);

  const coevalBlock = $('isPeer').checked
    ? `<div class="result-box"><strong>Coevaluó:</strong><br>${$('peerName').value}<br><strong>Fecha de coevaluación:</strong> ${$('peerDate').value || 'No registrada'}<br><strong>Puntaje de coevaluación:</strong><div class="score">${rub.total.toFixed(1)} / 8</div><p class="tiny">Criterios contestados: ${rub.answered}/8</p></div>`
    : `<div class="result-box"><strong>Coevaluación:</strong><br>No aplica<br><strong>Enviado:</strong><br>${now}</div>`;

  $('result').innerHTML = `<h2>Reporte de calificación</h2>
  <div class="result-grid">
    <div class="result-box"><strong>Identificador único:</strong><br><span class="unique-code">${uniqueId}</span><br><br><strong>Alumno:</strong><br>${$('studentName').value}<br><strong>Grado y grupo:</strong> ${$('grade').value} ${$('group').value}<br><strong>Fecha:</strong> ${$('date').value}<br><strong>Enviado:</strong><br>${now}</div>
    <div class="result-box"><strong>Calificación automática:</strong><div class="score">${grade10} / 10</div><strong>Aciertos:</strong> ${totalScore} / ${maxScore}<br><strong>Porcentaje:</strong> ${percent}%</div>
    ${coevalBlock}
  </div>
  <h3>Detalle por sección</h3>
  <div class="breakdown">
    <div><strong>Parte 1:</strong> ${p1Score}/${part1.length}</div>
    <div><strong>Parte 2:</strong> ${p2Score}/${substances.length}</div>
    <div><strong>Parte 3:</strong> ${p3Score}/${p3answers.length}</div>
    <div><strong>Parte 4:</strong> ${p4Score}/${p4cases.length * 2}</div>
    <div><strong>Parte 5:</strong> ${p5Score}/${life.length * 2}</div>
  </div>
  <h3>Indicaciones para entregar</h3><p>Toma una captura donde se vea esta sección completa con tu nombre, grado, grupo y calificación. También puedes usar la opción de imprimir del navegador y guardar como PDF.</p><p class="ios-note">En iPhone: toca <strong>Imprimir o guardar PDF</strong>, abre la vista previa con dos dedos y usa <strong>Compartir</strong> para guardarlo en Archivos.</p><button class="primary" type="button" id="printBtn">Imprimir o guardar PDF</button> <button class="secondary" type="button" id="printPageBtn">Abrir reporte imprimible</button>`;
  $('result').classList.remove('hidden'); lockForm(); $('printBtn').addEventListener('click', safePrint); $('printPageBtn').addEventListener('click', openPrintableReport); $('result').scrollIntoView({behavior:'smooth'});
});
$('resetBtn').addEventListener('click',()=>{ if(confirm('¿Seguro que deseas borrar todo y reiniciar?')){ localStorage.removeItem(ACTIVITY_ID_KEY); location.reload(); } });

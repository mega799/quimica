export interface StudentInfo {
  name: string;
  group: string;
  date: string;
  startTime: string;
  endTime?: string;
}

export interface ReadingStage {
  id: string;
  number: number;
  title: string;
  period: string;
  summary: string;
  fullText: string[];
  keyConcepts: string[];
  keyFigures: { name: string; period: string; contribution: string }[];
  inventionsAndTechniques: string[];
  icon: string;
  color: string;
}

export interface QuestionOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

export interface Question {
  id: string;
  missionId: number;
  title: string;
  prompt: string;
  explanation: string;
  hint: string;
  options: QuestionOption[];
}

export interface Mission {
  id: number;
  title: string;
  subtitle: string;
  stageName: string;
  description: string;
  icon: string;
  color: string;
  questions: Question[];
}

export interface MissionAttempt {
  missionId: number;
  attemptsCount: number;
  passed: boolean;
  scorePercent: number;
  completedAt?: string;
}

export interface RubricEvaluation {
  timeInTime: boolean; // +1 pt
  reviewedReading: boolean; // +1 pt
  understoodReading: boolean; // +1 pt
  completedIn3AttemptsOrLess: boolean; // +2 pts
  missionsCompletedCount: number; // 1 to 4 pts
  evidenceCaptured: boolean; // +1 pt
}

export interface AIFeedbackResponse {
  summary: string;
  strengths: string[];
  areasToReview: string[];
  pedagogicalNote: string;
}

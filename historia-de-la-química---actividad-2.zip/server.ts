import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Initialize Gemini AI
  const aiKey = process.env.GEMINI_API_KEY;
  const ai = aiKey
    ? new GoogleGenAI({
        apiKey: aiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          },
        },
      })
    : null;

  // API Health Check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', geminiAvailable: !!ai });
  });

  // AI Feedback Generator Endpoint
  app.post('/api/feedback', async (req, res) => {
    try {
      const {
        studentName,
        group,
        totalScore,
        missionsCompleted,
        attemptsPerMission,
        readAssignedText,
        comprehendedText,
        onTime,
        selfEvalCriteria,
      } = req.body;

      if (!ai) {
        // Fallback response if GEMINI_API_KEY is not configured yet
        return res.json({
          summary: `¡Excelente esfuerzo, ${studentName || 'Alumno'}! Has completado ${missionsCompleted} de 4 misiones con un puntaje de ${totalScore}/10.`,
          strengths: [
            'Dominio de las etapas históricas de la química',
            'Demostración de interés en la lectura de antecedentes',
            'Comprensión del avance del método científico',
          ],
          areasToReview: [
            totalScore < 10
              ? 'Repasar los postulados de la teoría del flogisto vs Lavoisier'
              : '¡Consolida tu aprendizaje investigando más sobre John Dalton y los átomos!',
          ],
          pedagogicalNote: '¡Sigue así! La Química está presente en todo lo que nos rodea.',
        });
      }

      const prompt = `Eres un profesor entusiasta y pedagógico de Química de 1º de Preparatoria.
Genera una retroalimentación personalizada en idioma ESPAÑOL para el alumno(a): "${studentName || 'Estudiante'}".

Datos de desempeño en la Actividad 2 "Antecedentes Históricos de la Química":
- Calificación obtenida: ${totalScore} / 10 puntos según la rúbrica oficial.
- Misiones completadas: ${missionsCompleted} de 4 (Prehistoria, Griegos, Alquimia, Flogisto vs Química Moderna).
- Intentos por misión: Misión 1: ${attemptsPerMission?.[0] || 1} int., Misión 2: ${attemptsPerMission?.[1] || 1} int., Misión 3: ${attemptsPerMission?.[2] || 1} int., Misión 4: ${attemptsPerMission?.[3] || 1} int.
- Revisó la lectura previamente: ${readAssignedText ? 'Sí' : 'No'}
- Comprendió los textos antes de responder: ${comprehendedText ? 'Sí' : 'No'}
- Entrega a tiempo: ${onTime ? 'Sí' : 'No'}

Proporciona la respuesta ÚNICAMENTE en formato JSON válido con este esquema:
{
  "summary": "Resumen personalizado y motivador de 2-3 oraciones dirigido al alumno",
  "strengths": ["Fortaleza 1 alcanzada", "Fortaleza 2 relacionada a la historia de la química"],
  "areasToReview": ["Punto clave a repasar o felicitar según su desempeño"],
  "pedagogicalNote": "Una nota inspiradora conectando la química con la vida cotidiana y el método científico"
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const text = response.text || '';
      try {
        const parsed = JSON.parse(text);
        return res.json(parsed);
      } catch (parseErr) {
        return res.json({
          summary: text || `¡Bien hecho ${studentName}! Has obtenido ${totalScore}/10 puntos.`,
          strengths: ['Comprensión histórica', 'Resolución de misiones'],
          areasToReview: ['Repaso general de la lectura'],
          pedagogicalNote: '¡La ciencia es un proceso continuo de descubrimiento!',
        });
      }
    } catch (err: any) {
      console.error('Error generating AI feedback:', err);
      return res.status(500).json({ error: 'No se pudo generar la retroalimentación en este momento.' });
    }
  });

  // Vite middleware setup for dev vs production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Servidor de Química listo en http://localhost:${PORT}`);
  });
}

startServer();

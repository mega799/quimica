# Molecu-IA · Métodos de separación de mezclas

Sitio estático listo para publicar en Netlify.

## Publicación rápida

1. Entra a Netlify y elige **Add new site → Deploy manually**.
2. Arrastra esta carpeta completa o el archivo `index.html`.
3. El sitio funcionará sin instalar nada ni configurar comandos de compilación.

La actividad incluye datos del estudiante, seis misiones, calificación automática, coevaluación con puntaje y vista de impresión/guardado como PDF.

import React from 'react';
import { StudentInfo } from '../types';
import { BookOpen, Gamepad2, ClipboardCheck, FileCheck2, Clock, Trophy, Atom } from 'lucide-react';

interface HeaderProps {
  student: StudentInfo;
  setStudent: React.Dispatch<React.SetStateAction<StudentInfo>>;
  activeTab: 'reading' | 'missions' | 'rubric' | 'evidence';
  setActiveTab: (tab: 'reading' | 'missions' | 'rubric' | 'evidence') => void;
  totalScore: number;
  completedMissionsCount: number;
  elapsedTimeString: string;
}

export const Header: React.FC<HeaderProps> = ({
  student,
  setStudent,
  activeTab,
  setActiveTab,
  totalScore,
  completedMissionsCount,
  elapsedTimeString,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md text-slate-800 border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5">
        {/* Top level bar: Brand, Student Info */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 sm:gap-4">
          <div className="flex items-center gap-2.5 sm:gap-3.5">
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-bold text-lg sm:text-xl shadow-sm shadow-indigo-500/20 shrink-0">
              <Atom className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
            </div>

            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-2 py-0.5 text-[9px] sm:text-[10px] font-bold bg-indigo-100 text-indigo-700 rounded-full uppercase tracking-wider">
                  Química Inorgánica · 1º Prepa
                </span>
                <span className="text-[11px] sm:text-xs text-slate-500 flex items-center gap-1 font-mono">
                  <Clock className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-indigo-500" />
                  {elapsedTimeString}
                </span>
              </div>
              <h1 className="text-sm sm:text-lg font-bold text-slate-800 tracking-tight leading-snug mt-0.5 truncate">
                Actividad 2: Antecedentes Históricos
              </h1>
            </div>
          </div>

          {/* Student name & Group Input */}
          <div className="flex items-center justify-between sm:justify-end gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-50 border border-slate-200 rounded-xl sm:rounded-2xl p-1 sm:p-1.5 px-2.5 sm:px-3 text-xs shadow-sm flex-1 sm:flex-initial">
              <span className="text-slate-500 font-semibold text-[11px] sm:text-xs">Alumno:</span>
              <input
                type="text"
                value={student.name}
                onChange={(e) => setStudent((prev) => ({ ...prev, name: e.target.value }))}
                placeholder="Nombre completo"
                className="bg-white border border-slate-200 text-slate-800 text-xs rounded-lg sm:rounded-xl px-2 py-1 w-28 sm:w-36 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium min-h-[36px] sm:min-h-0"
              />
              <span className="text-slate-500 font-semibold text-[11px] sm:text-xs ml-0.5">Gpo:</span>
              <input
                type="text"
                value={student.group}
                onChange={(e) => setStudent((prev) => ({ ...prev, group: e.target.value }))}
                placeholder="1ºA"
                className="bg-white border border-slate-200 text-slate-800 text-xs rounded-lg sm:rounded-xl px-1.5 py-1 w-14 sm:w-20 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium min-h-[36px] sm:min-h-0"
              />
            </div>

            {/* Score Pill */}
            <div className="flex items-center gap-1.5 bg-indigo-900 text-white rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2 text-xs font-bold shadow-sm shrink-0 min-h-[36px]">
              <Trophy className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-300" />
              <span>{totalScore} / 10 pts</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1.5 sm:gap-2 mt-2.5 sm:mt-3.5 overflow-x-auto pb-1 border-t border-slate-100 pt-2.5 scrollbar-none -mx-3 px-3 sm:mx-0 sm:px-0">
          <button
            onClick={() => setActiveTab('reading')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2 rounded-xl sm:rounded-2xl text-xs font-bold transition-all whitespace-nowrap min-h-[40px] sm:min-h-0 ${
              activeTab === 'reading'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <BookOpen className="w-4 h-4 shrink-0" />
            <span>1. Lectura</span>
          </button>

          <button
            onClick={() => setActiveTab('missions')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2 rounded-xl sm:rounded-2xl text-xs font-bold transition-all whitespace-nowrap min-h-[40px] sm:min-h-0 ${
              activeTab === 'missions'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Gamepad2 className="w-4 h-4 shrink-0" />
            <span>2. Misiones</span>
            <span className="bg-indigo-100 text-indigo-700 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
              {completedMissionsCount}/4
            </span>
          </button>

          <button
            onClick={() => setActiveTab('rubric')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2 rounded-xl sm:rounded-2xl text-xs font-bold transition-all whitespace-nowrap min-h-[40px] sm:min-h-0 ${
              activeTab === 'rubric'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <ClipboardCheck className="w-4 h-4 shrink-0" />
            <span>3. Autoevaluación</span>
          </button>

          <button
            onClick={() => setActiveTab('evidence')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2 rounded-xl sm:rounded-2xl text-xs font-bold transition-all whitespace-nowrap min-h-[40px] sm:min-h-0 ${
              activeTab === 'evidence'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <FileCheck2 className="w-4 h-4 shrink-0" />
            <span>4. Evidencia</span>
          </button>
        </nav>
      </div>
    </header>
  );
};

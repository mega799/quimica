import React from 'react';
import { StudentInfo } from '../types';
import { Printer, Download, CheckCircle2, QrCode, ShieldCheck, Trophy, Calendar, Clock } from 'lucide-react';

interface EvidenceVoucherProps {
  student: StudentInfo;
  reviewedReading: boolean;
  understoodReading: boolean;
  onTime: boolean;
  completedMissions: boolean[];
  attemptsPerMission: number[];
  evidenceCaptured: boolean;
}

export const EvidenceVoucher: React.FC<EvidenceVoucherProps> = ({
  student,
  reviewedReading,
  understoodReading,
  onTime,
  completedMissions,
  attemptsPerMission,
  evidenceCaptured,
}) => {
  const completedMissionsCount = completedMissions.filter(Boolean).length;
  const maxAttempts = Math.max(...attemptsPerMission, 0);
  const completedIn3AttemptsOrLess = completedMissionsCount === 4 && maxAttempts <= 3;

  // Criteria score calculation
  const scoreTime = onTime ? 1 : 0;
  const scoreReview = reviewedReading ? 1 : 0;
  const scoreComprehend = understoodReading ? 1 : 0;
  const score3Attempts = completedIn3AttemptsOrLess ? 2 : 0;
  const scoreMissions = completedMissionsCount; // 1 to 4 pts
  const scoreEvidence = evidenceCaptured ? 1 : 0;

  const totalScore = scoreTime + scoreReview + scoreComprehend + score3Attempts + scoreMissions + scoreEvidence;

  const timestamp = student.endTime || new Date().toLocaleString('es-MX', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-3 sm:space-y-4 max-w-5xl mx-auto">
      {/* Top bar controls */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl p-3 sm:p-4 print:hidden">
        <div>
          <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            Comprobante Oficial de Evidencia Digital
          </h3>
          <p className="text-[11px] text-slate-400">
            Captura o imprime este documento oficial para adjuntar a tu aula virtual.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all min-h-[44px]"
        >
          <Printer className="w-4 h-4" />
          Imprimir / Guardar PDF
        </button>
      </div>

      {/* Single-Screen Compact Printable Voucher Container */}
      <div className="bg-white text-slate-900 rounded-2xl p-4 sm:p-6 border border-slate-200 shadow-xl space-y-3.5 font-sans print:shadow-none print:border-none print:p-0 print:m-0">
        {/* Official Letterhead */}
        <div className="border-b-2 border-slate-900 pb-2.5 flex items-center justify-between gap-2">
          <div>
            <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-widest text-slate-600 block">
              DEPARTAMENTO DE CIENCIAS QUÍMICOBIOLÓGICAS · PREPARATORIA
            </span>
            <h1 className="text-xs sm:text-base font-black text-slate-900 uppercase tracking-tight leading-tight">
              QUÍMICA INORGÁNICA — ACTIVIDAD 2: ANTECEDENTES HISTÓRICOS DE LA QUÍMICA
            </h1>
          </div>
          <div className="text-right shrink-0">
            <span className="text-[10px] sm:text-xs font-bold text-slate-900 block">EVIDENCIA DIGITAL</span>
            <span className="text-[9px] font-mono text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-300">
              QIM-2026-ACT2
            </span>
          </div>
        </div>

        {/* Student metadata grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 bg-slate-50 p-2.5 sm:p-3 rounded-xl border border-slate-200 text-[11px] sm:text-xs">
          <div className="min-w-0">
            <span className="text-slate-500 font-medium block text-[10px]">Alumno(a):</span>
            <span className="font-bold text-slate-900 truncate block">{student.name || 'Sin especificar'}</span>
          </div>
          <div>
            <span className="text-slate-500 font-medium block text-[10px]">Grupo:</span>
            <span className="font-bold text-slate-900">{student.group || '1ºA'}</span>
          </div>
          <div className="min-w-0">
            <span className="text-slate-500 font-medium block text-[10px] flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-500" /> Fecha:
            </span>
            <span className="font-mono text-slate-900 text-[10px] truncate block">{timestamp}</span>
          </div>
          <div className="text-right">
            <span className="text-slate-500 font-medium block text-[10px]">Calificación:</span>
            <span className="font-black text-emerald-700 text-xs sm:text-sm">{totalScore} / 10 Pts</span>
          </div>
        </div>

        {/* Missions Badge Strip */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-center space-y-1.5">
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-700 uppercase tracking-wider px-1">
            <span>Logros de Misiones Interactivas</span>
            <span className="text-emerald-700 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" /> Verificación Digital
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
            {completedMissions.map((passed, idx) => (
              <div
                key={idx}
                className={`p-1.5 sm:p-2 rounded-lg border text-center text-[11px] font-bold ${
                  passed
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                <div className="text-[9px] text-slate-500 uppercase">Misión {idx + 1}</div>
                <div className="text-[10px] sm:text-xs font-bold leading-none mt-0.5">
                  {passed ? '✓ COMPLETADA' : '✗ PENDIENTE'}
                </div>
                <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                  ({attemptsPerMission[idx] || 1} int.)
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Compact Rubric Table */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-[10px] font-bold text-slate-800 uppercase">
            <span>Lista de Cotejo & Autoevaluación Oficial</span>
            <span className="font-mono text-slate-500">PCEyT 1 · PCyCD8</span>
          </div>

          <div className="overflow-x-auto rounded-lg border border-slate-300">
            <table className="w-full text-left text-[10px] sm:text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300">
                  <th className="p-1.5 sm:p-2 border-r border-slate-300">CRITERIO</th>
                  <th className="p-1.5 sm:p-2 text-center border-r border-slate-300 w-16 sm:w-20">SÍ</th>
                  <th className="p-1.5 sm:p-2 text-center border-r border-slate-300 w-16 sm:w-20">NO</th>
                  <th className="p-1.5 sm:p-2 text-center w-20 sm:w-24">PUNTOS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300 leading-tight">
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">Realicé la actividad en el tiempo señalado.</td>
                  <td className={`p-1.5 text-center border-r border-slate-300 font-bold ${onTime ? 'bg-emerald-50 text-emerald-900' : ''}`}>
                    +1 pt
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 ${!onTime ? 'bg-rose-50 text-rose-900' : ''}`}>
                    0 pt
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">{scoreTime} pt</td>
                </tr>
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">Revisé la lectura asignada antes de jugar.</td>
                  <td className={`p-1.5 text-center border-r border-slate-300 font-bold ${reviewedReading ? 'bg-emerald-50 text-emerald-900' : ''}`}>
                    +1 pt
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 ${!reviewedReading ? 'bg-rose-50 text-rose-900' : ''}`}>
                    0 pt
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">{scoreReview} pt</td>
                </tr>
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">Comprendí la información de la lectura.</td>
                  <td className={`p-1.5 text-center border-r border-slate-300 font-bold ${understoodReading ? 'bg-emerald-50 text-emerald-900' : ''}`}>
                    +1 pt
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 ${!understoodReading ? 'bg-rose-50 text-rose-900' : ''}`}>
                    0 pt
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">{scoreComprehend} pt</td>
                </tr>
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">
                    Completé misiones en 3 intentos o menos.
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 font-bold ${completedIn3AttemptsOrLess ? 'bg-emerald-50 text-emerald-900' : ''}`}>
                    +2 pts
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 ${!completedIn3AttemptsOrLess ? 'bg-rose-50 text-rose-900' : ''}`}>
                    0 pt
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">{score3Attempts} pts</td>
                </tr>
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">Misiones completadas ({completedMissionsCount}/4).</td>
                  <td colSpan={2} className="p-1.5 text-center border-r border-slate-300 font-medium text-slate-700">
                    +{scoreMissions} pts
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">+{scoreMissions} pts</td>
                </tr>
                <tr>
                  <td className="p-1.5 sm:p-2 border-r border-slate-300">
                    Captura / Evidencia con fecha y hora sin editar.
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 font-bold ${evidenceCaptured ? 'bg-emerald-50 text-emerald-900' : ''}`}>
                    +1 pt
                  </td>
                  <td className={`p-1.5 text-center border-r border-slate-300 ${!evidenceCaptured ? 'bg-rose-50 text-rose-900' : ''}`}>
                    0 pt
                  </td>
                  <td className="p-1.5 text-center font-bold text-slate-900">{scoreEvidence} pt</td>
                </tr>
                <tr className="bg-slate-100 font-bold border-t border-slate-300">
                  <td colSpan={3} className="p-1.5 sm:p-2 text-right border-r border-slate-300 uppercase text-slate-900">
                    CALIFICACIÓN TOTAL:
                  </td>
                  <td className="p-1.5 sm:p-2 text-center text-emerald-800 text-xs sm:text-sm">{totalScore} / 10 Pts</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Signature Box */}
        <div className="pt-2 sm:pt-3 border-t border-slate-300 flex items-end justify-between gap-4">
          <div className="flex-1 max-w-sm">
            <span className="text-[9px] font-bold text-slate-600 block uppercase mb-1">
              Nombre o firma autógrafa del alumno:
            </span>
            <div className="border-b-2 border-slate-900 pt-3 text-xs sm:text-sm font-bold text-slate-900">
              {student.name || '_____________________________________'}
            </div>
          </div>

          <div className="flex items-center gap-2 text-right shrink-0">
            <div className="text-[9px] text-slate-500 leading-tight hidden sm:block">
              <span className="font-bold block text-slate-800">Sello de Validación</span>
              Verificado por Sistema
            </div>
            <div className="w-10 h-10 bg-slate-100 border border-slate-300 rounded-lg flex items-center justify-center text-slate-800">
              <QrCode className="w-6 h-6" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

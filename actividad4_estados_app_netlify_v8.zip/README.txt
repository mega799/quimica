Actividad 4 - Aplicación web para Netlify

Archivos incluidos:
- index.html
- styles.css
- app.js
- netlify.toml

Para subir a Netlify: arrastra esta carpeta o el archivo ZIP al panel de Netlify.

PDF en iPhone:
1. Enviar la actividad.
2. Tocar Imprimir o guardar PDF.
3. En la pantalla de impresión, abrir la vista previa con dos dedos.
4. Tocar Compartir y guardar en Archivos o compartir el PDF.

Si el navegador no abre impresión, usar Abrir reporte imprimible.

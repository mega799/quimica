Actividad 8-UI · Aplicación web para Netlify

1. Sube el contenido de esta carpeta a Netlify (o arrastra la carpeta comprimida).
2. Abre index.html desde el sitio publicado.
3. El botón «Guardar PDF» abre el diálogo de impresión del navegador; en iPhone selecciona Compartir > Guardar en Archivos.
4. «Abrir reporte imprimible» deja el reporte abierto para revisarlo o guardarlo manualmente.

La aplicación no requiere instalación, servidor ni API externa.

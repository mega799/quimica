import React from 'react';
import { StudentInfo } from '../types';
import { AIFeedbackCard } from './AIFeedbackCard';
import { ClipboardCheck, Check, X, Trophy, FileText, ArrowRight } from 'lucide-react';

interface RubricTrackerProps {
  student: StudentInfo;
  reviewedReading: boolean;
  understoodReading: boolean;
  onTime: boolean;
  completedMissions: boolean[];
  attemptsPerMission: number[];
  evidenceCaptured: boolean;
  onToggleOnTime: () => void;
  onToggleReviewedReading: () => void;
  onToggleUnderstoodReading: () => void;
  onToggleEvidenceCaptured: () => void;
  onGoToEvidence: () => void;
}

export const RubricTracker: React.FC<RubricTrackerProps> = ({
  student,
  reviewedReading,
  understoodReading,
  onTime,
  completedMissions,
  attemptsPerMission,
  evidenceCaptured,
  onToggleOnTime,
  onToggleReviewedReading,
  onToggleUnderstoodReading,
  onToggleEvidenceCaptured,
  onGoToEvidence,
}) => {
  const completedMissionsCount = completedMissions.filter(Boolean).length;
  const maxAttempts = Math.max(...attemptsPerMission, 0);
  const completedIn3AttemptsOrLess = completedMissionsCount === 4 && maxAttempts <= 3;

  // Criteria score calculation
  const scoreTime = onTime ? 1 : 0;
  const scoreReview = reviewedReading ? 1 : 0;
  const scoreComprehend = understoodReading ? 1 : 0;
  const score3Attempts = completedIn3AttemptsOrLess ? 2 : 0;
  const scoreMissions = completedMissionsCount; // 1 to 4 pts
  const scoreEvidence = evidenceCaptured ? 1 : 0;

  const totalScore = scoreTime + scoreReview + scoreComprehend + score3Attempts + scoreMissions + scoreEvidence;

  return (
    <div className="space-y-8">
      {/* Rubric Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <span className="px-2.5 py-0.5 text-[10px] font-bold bg-indigo-100 text-indigo-700 rounded-full uppercase tracking-widest">
              Población: 1º de Preparatoria · Química Inorgánica
            </span>
            <h2 className="text-xl font-bold text-slate-800 tracking-tight mt-1">
              Lista de Cotejo & Autoevaluación Oficial (Actividad 2)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              PROPÓSITOS: <span className="font-mono text-indigo-600 font-semibold">PCEyT 1 · PCyCD8</span>
            </p>
          </div>

          <div className="bg-indigo-900 border border-indigo-800 rounded-2xl p-4 text-center min-w-[200px] text-white shadow-sm">
            <span className="text-[10px] uppercase tracking-wider text-indigo-200 font-bold block">TOTAL DE PUNTOS</span>
            <div className="text-3xl font-black text-amber-300 flex items-center justify-center gap-1.5 mt-0.5">
              <Trophy className="w-6 h-6 text-amber-300" />
              {totalScore} / 10
            </div>
            <span className="text-[10px] text-indigo-200">Calificación final calculada</span>
          </div>
        </div>

        {/* Table representation matching Document 2 page 2 */}
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-800/80 text-slate-300 font-bold border-b border-slate-700">
                <th className="p-3 w-12 text-center">#</th>
                <th className="p-3">CRITERIO DE EVALUACIÓN</th>
                <th className="p-3 text-center w-32">SI</th>
                <th className="p-3 text-center w-32">NO</th>
                <th className="p-3 text-center w-28">PUNTOS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {/* Criterion 1: On time */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">1</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Tiempo de Entrega</div>
                  <div className="text-[11px] text-slate-400">Realicé la actividad en el tiempo señalado por mi docente.</div>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleOnTime}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      onTime
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +1 PUNTO
                  </button>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleOnTime}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      !onTime
                        ? 'bg-rose-500 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +0 PUNTOS
                  </button>
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{scoreTime} pt</td>
              </tr>

              {/* Criterion 2: Reviewed Reading */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">2</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Revisión de Lectura Asignada</div>
                  <div className="text-[11px] text-slate-400">Revisé la lectura asignada antes de comenzar a contestar en la aplicación.</div>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleReviewedReading}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      reviewedReading
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +1 PUNTO
                  </button>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleReviewedReading}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      !reviewedReading
                        ? 'bg-rose-500 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +0 PUNTOS
                  </button>
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{scoreReview} pt</td>
              </tr>

              {/* Criterion 3: Understood Reading */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">3</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Comprensión de Información</div>
                  <div className="text-[11px] text-slate-400">Comprendí la información de la lectura antes de comenzar a jugar.</div>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleUnderstoodReading}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      understoodReading
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +1 PUNTO
                  </button>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleUnderstoodReading}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      !understoodReading
                        ? 'bg-rose-500 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +0 PUNTOS
                  </button>
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{scoreComprehend} pt</td>
              </tr>

              {/* Criterion 4: All 4 missions in 3 attempts or less */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">4</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Eficacia en Misiones (en 3 Intentos o menos)</div>
                  <div className="text-[11px] text-slate-400">Logré completar todas las misiones del juego en 3 intentos o menos.</div>
                </td>
                <td className="p-3 text-center">
                  <span
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold inline-block ${
                      completedIn3AttemptsOrLess ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    +2 PUNTOS
                  </span>
                </td>
                <td className="p-3 text-center">
                  <span
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold inline-block ${
                      !completedIn3AttemptsOrLess ? 'bg-rose-500/80 text-white' : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    +0 PUNTO
                  </span>
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{score3Attempts} pts</td>
              </tr>

              {/* Criterion 5: Missions completed (1 to 4 pts) */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">5</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Logro de Misiones Históricas</div>
                  <div className="text-[11px] text-slate-400">
                    1 misión (+1 pt) · 2 misiones (+2 pts) · 3 misiones (+3 pts) · 4 misiones (+4 pts)
                  </div>
                </td>
                <td colSpan={2} className="p-3 text-center font-mono font-semibold text-cyan-300">
                  {completedMissionsCount} de 4 misiones completadas
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{scoreMissions} pts</td>
              </tr>

              {/* Criterion 6: Evidence voucher / screenshot */}
              <tr className="hover:bg-slate-800/40 transition-colors">
                <td className="p-3 text-center font-mono text-slate-400">6</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-100">Evidencia de Trabajo con Fecha y Hora</div>
                  <div className="text-[11px] text-slate-400">
                    Tomé la captura/comprobante de evidencia mostrando fecha y hora en que realicé la actividad.
                  </div>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleEvidenceCaptured}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      evidenceCaptured
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +1 PUNTO
                  </button>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={onToggleEvidenceCaptured}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      !evidenceCaptured
                        ? 'bg-rose-500 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    +0 PUNTOS
                  </button>
                </td>
                <td className="p-3 text-center font-bold text-emerald-400 text-sm">+{scoreEvidence} pt</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Action Button to Generate Evidence */}
        <div className="flex justify-end pt-2">
          <button
            onClick={onGoToEvidence}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/20 transition-all"
          >
            <FileText className="w-4 h-4" />
            Generar Comprobante de Evidencia Digital
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* AI Feedback Module */}
      <AIFeedbackCard
        student={student}
        totalScore={totalScore}
        completedMissionsCount={completedMissionsCount}
        attemptsPerMission={attemptsPerMission}
        reviewedReading={reviewedReading}
        understoodReading={understoodReading}
        onTime={onTime}
      />
    </div>
  );
};

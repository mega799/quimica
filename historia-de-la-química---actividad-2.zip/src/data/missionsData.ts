import { Mission } from '../types';

export const MISSIONS: Mission[] = [
  {
    id: 1,
    title: 'Misión 1: Prehistoria y los Metales',
    subtitle: 'El Dominio del Fuego y la Metalurgia Primitiva',
    stageName: 'Prehistoria y Antigüedad',
    description: 'Demuestra tu comprensión sobre el descubrimiento del fuego, la edad de los metales (Oro, Bronce, Hierro) y la producción del Acero y artesanías egipcias.',
    icon: 'Flame',
    color: 'amber',
    questions: [
      {
        id: 'm1_q1',
        missionId: 1,
        title: 'El Origen de la Química',
        prompt: '¿En qué momento histórico surge la química y cuál fue el evento desencadenante principal?',
        explanation: 'La Química surge en la prehistoria (100,000 a.C. a 600 a.C.) cuando los homínidos descubren el fuego y lo usan para cocinar alimentos y manipular metales.',
        hint: 'Recuerda el elemento que producía calor y luz en las cavernas para la cocina y la metalurgia.',
        options: [
          { id: 'a', text: 'Con la publicación de la tabla periódica de los elementos en el siglo XIX.', isCorrect: false },
          { id: 'b', text: 'Al pintar animales en las paredes de las cavernas utilizando únicamente carbón vegetal.', isCorrect: false },
          { id: 'c', text: 'Cuando los homínidos descubrieron el fuego y lo usaron para cocinar y procesar metales (metalurgia).', isCorrect: true },
          { id: 'd', text: 'Cuando los griegos construyeron el Partenón de Atenas.', isCorrect: false }
        ]
      },
      {
        id: 'm1_q2',
        missionId: 1,
        title: 'La Invención del Acero',
        prompt: '¿Cómo lograron los antiguos construir armas y herramientas más resistentes perfeccionando la aleación del Acero?',
        explanation: 'Obtuvieron el acero mezclando al fuego hierro con carbón de leña, creando una aleación más dura y resistente.',
        hint: 'Pensaron en combinar el metal de la edad de hierro con el residuo del carbón de leña.',
        options: [
          { id: 'a', text: 'Fundiendo cobre puro con estaño en agua fría.', isCorrect: false },
          { id: 'b', text: 'Mezclando al fuego el hierro con carbón de leña.', isCorrect: true },
          { id: 'c', text: 'Combinando oro nativo con sal marina en las cavernas.', isCorrect: false },
          { id: 'd', text: 'Pintando espadas de piedra con cinabrio rojo.', isCorrect: false }
        ]
      },
      {
        id: 'm1_q3',
        missionId: 1,
        title: 'La Edad del Bronce',
        prompt: 'La edad del bronce (4,000 a.C.) revolucionó la elaboración de herramientas mediante una aleación. ¿Qué metales la componen?',
        explanation: 'El bronce es una aleación metálica formada principalmente por la mezcla de Cobre con Estaño.',
        hint: 'Uno es de color rojizo y el otro es un metal blando plateado.',
        options: [
          { id: 'a', text: 'Cobre con Estaño', isCorrect: true },
          { id: 'b', text: 'Hierro con Carbón de leña', isCorrect: false },
          { id: 'c', text: 'Oro con Plata nativa', isCorrect: false },
          { id: 'd', text: 'Plomo con Mercurio líquido', isCorrect: false }
        ]
      },
      {
        id: 'm1_q4',
        missionId: 1,
        title: 'El Primer Metal Utilizado',
        prompt: '¿Cuál fue el primer metal trabajado por el ser humano hacia el 5,000 a.C. debido a que se encontraba libre en la naturaleza?',
        explanation: 'El oro fue el primer metal descubierto y trabajado (5,000 a.C.) por encontrarse en estado nativo brillante.',
        hint: 'Es un metal precioso brillante que no se oxida fácilmente.',
        options: [
          { id: 'a', text: 'El Aluminio', isCorrect: false },
          { id: 'b', text: 'El Titanio', isCorrect: false },
          { id: 'c', text: 'El Acero inoxidable', isCorrect: false },
          { id: 'd', text: 'El Oro', isCorrect: true }
        ]
      },
      {
        id: 'm1_q5',
        missionId: 1,
        title: 'Las Artesanías y Técnicas Egipcias',
        prompt: '¿Qué aportaciones químicas fundamentales desarrollaron los egipcios entre el 3,000 a.C. y el 400 a.C.?',
        explanation: 'Los egipcios destacaron en embalsamamiento, elaboración de jabones, aceites, cosméticos, alfarería y cerámicas.',
        hint: 'Revisa las técnicas de conservación de momias y cosmética antigua.',
        options: [
          { id: 'a', text: 'La invención de la pólvora y el plástico sintético.', isCorrect: false },
          { id: 'b', text: 'Técnicas de embalsamamiento, elaboración de jabones, cerámicas, aceites y cosméticos.', isCorrect: true },
          { id: 'c', text: 'La síntesis industrial del ácido sulfúrico.', isCorrect: false },
          { id: 'd', text: 'La fisión nuclear y el uso del radio.', isCorrect: false }
        ]
      },
      {
        id: 'm1_q6',
        missionId: 1,
        title: 'Secuencia Cronológica de los Metales',
        prompt: '¿Cuál es el orden cronológico correcto del uso de los metales en la antigüedad?',
        explanation: 'La secuencia histórica fue: Edad del Oro (5,000 a.C.) -> Edad del Bronce (4,000 a.C.) -> Edad del Hierro (1,200 a.C.).',
        hint: 'Empieza con el metal precioso nativo, sigue la aleación de cobre y estaño, y termina con el metal de las espadas de hierro.',
        options: [
          { id: 'a', text: 'Hierro -> Bronce -> Oro', isCorrect: false },
          { id: 'b', text: 'Bronce -> Hierro -> Oro', isCorrect: false },
          { id: 'c', text: 'Oro -> Bronce -> Hierro', isCorrect: true },
          { id: 'd', text: 'Acero -> Aluminio -> Cobre', isCorrect: false }
        ]
      }
    ]
  },
  {
    id: 2,
    title: 'Misión 2: Filosofía Griega y el Átomo',
    subtitle: 'Los Cuatro Elementos y la Partícula Indivisible',
    stageName: 'Griegos',
    description: 'Pon a prueba tus conocimientos sobre los filósofos griegos (Tales, Heráclito, Empédocles, Aristóteles) y la idea original de Leucipo y Demócrito.',
    icon: 'Atom',
    color: 'blue',
    questions: [
      {
        id: 'm2_q1',
        missionId: 2,
        title: 'El Principio del Agua',
        prompt: '¿Qué filósofo griego (640-560 a.C.) sostenía que el AGUA era la sustancia básica primordial de todas las cosas porque "sin agua no hay vida"?',
        explanation: 'Tales de Mileto argumentaba que el agua era el principio (arché) fundamental de la naturaleza.',
        hint: 'Es conocido como el filósofo de Mileto que observó la importancia del agua para la vida.',
        options: [
          { id: 'a', text: 'Tales de Mileto', isCorrect: true },
          { id: 'b', text: 'Heráclito de Éfeso', isCorrect: false },
          { id: 'c', text: 'Aristóteles de Estagira', isCorrect: false },
          { id: 'd', text: 'Demócrito de Abdera', isCorrect: false }
        ]
      },
      {
        id: 'm2_q2',
        missionId: 2,
        title: 'El Nacimiento del Concepto de Átomo',
        prompt: 'En los siglos V y IV a.C., ¿quiénes plantearon que la materia se divide hasta una partícula límite indivisible llamada «átomo» (a = sin, tomo = división)?',
        explanation: 'Leucipo y su discípulo Demócrito propusieron por primera vez la teoría atomista filosófica.',
        hint: 'Se trata de un maestro y su célebre discípulo de la escuela atomista.',
        options: [
          { id: 'a', text: 'Tales de Mileto y Anaxímenes', isCorrect: false },
          { id: 'b', text: 'Aristóteles y Platón', isCorrect: false },
          { id: 'c', text: 'Johann Becher y Georg Stahl', isCorrect: false },
          { id: 'd', text: 'Leucipo y su discípulo Demócrito', isCorrect: true }
        ]
      },
      {
        id: 'm2_q3',
        missionId: 2,
        title: 'El Dominio de los 4 Elementos',
        prompt: '¿Por qué la teoría de los 4 elementos (Agua, Aire, Fuego, Tierra) se mantuvo vigente durante casi 2,000 años?',
        explanation: 'Fue defendida, explicada y divulgada por Aristóteles (300 a.C.), cuya inmensa autoridad filosófica hizo que perdurara hasta la Edad Moderna.',
        hint: 'Piensa en el gran filósofo tutor de Alejandro Magno que añadió las 4 cualidades de la materia.',
        options: [
          { id: 'a', text: 'Porque demostraron la teoría midiendo los elementos con balanzas digitales.', isCorrect: false },
          { id: 'b', text: 'Porque fue divulgada y defendida por Aristóteles, una de las figuras más influyentes de la época.', isCorrect: true },
          { id: 'c', text: 'Porque los alquimistas prohibieron estudiar otras teorías.', isCorrect: false },
          { id: 'd', text: 'Porque nadie volvió a hacerse preguntas sobre la materia.', isCorrect: false }
        ]
      },
      {
        id: 'm2_q4',
        missionId: 2,
        title: 'Las Cuatro Cualidades de Aristóteles',
        prompt: 'Además de los 4 elementos, ¿qué 4 cualidades fundamentales combinaba Aristóteles para explicar la materia?',
        explanation: 'Aristóteles combinaba las cualidades: Caliente, Frío, Húmedo y Seco (por ejemplo: caliente + húmedo = aire).',
        hint: 'Son dos parejas de sensaciones opuestas de temperatura y humedad.',
        options: [
          { id: 'a', text: 'Pesado, Ligero, Transparente y Opaco', isCorrect: false },
          { id: 'b', text: 'Ácido, Básico, Neutro y Salado', isCorrect: false },
          { id: 'c', text: 'Caliente, Frío, Húmedo y Seco', isCorrect: true },
          { id: 'd', text: 'Sólido, Líquido, Gaseoso y Plasma', isCorrect: false }
        ]
      },
      {
        id: 'm2_q5',
        missionId: 2,
        title: 'Pigmentos Antiguos y Toxicidad',
        prompt: '¿Qué sustancia utilizaban las mujeres antiguas para pintarse los labios de rojo sin saber que era un sulfuro de mercurio tóxico?',
        explanation: 'Utilizaban el cinabrio (sulfuro de mercurio) como labial, ignorando que producía un envenenamiento lento por mercurio.',
        hint: 'Es un mineral de color rojo vivo que contiene un metal líquido.',
        options: [
          { id: 'a', text: 'Cinabrio (sulfuro de mercurio)', isCorrect: true },
          { id: 'b', text: 'Óxido de hierro amarillo', isCorrect: false },
          { id: 'c', text: 'Sulfato de cobre azul', isCorrect: false },
          { id: 'd', text: 'Carbonato de calcio blanco', isCorrect: false }
        ]
      },
      {
        id: 'm2_q6',
        missionId: 2,
        title: 'Heráclito y el Fuego',
        prompt: '¿Qué filósofo griego (400 a.C.) sostenía que el FUEGO era el elemento primordial debido a su cambio constante e incesante?',
        explanation: 'Heráclito de Éfeso consideraba al fuego como el principio generador de la naturaleza en constante transformación.',
        hint: 'Asociaba el elemento ardiente con el cambio incesante de las cosas.',
        options: [
          { id: 'a', text: 'Tales de Mileto', isCorrect: false },
          { id: 'b', text: 'Anaxímenes', isCorrect: false },
          { id: 'c', text: 'Empédocles', isCorrect: false },
          { id: 'd', text: 'Heráclito', isCorrect: true }
        ]
      }
    ]
  },
  {
    id: 3,
    title: 'Misión 3: El Laboratorio Secreto de los Alquimistas',
    subtitle: 'Técnicas, Equipos y la Búsqueda Mística',
    stageName: 'Alquimia',
    description: 'Aventura en el laboratorio medieval: explora los inventos de los alquimistas (alambique, baño María, agua regia), la clasificación de Geber y Paracelso.',
    icon: 'Sparkles',
    color: 'purple',
    questions: [
      {
        id: 'm3_q1',
        missionId: 3,
        title: 'Los Grandes Objetivos de la Alquimia',
        prompt: '¿Cuáles eran los dos grandes logros legendarios que buscaban alcanzar los alquimistas medievales?',
        explanation: 'Buscaban la Piedra Filosofal (transmutar metales en oro) y el Elixir de la Vida (una infusión para obtener la inmortalidad).',
        hint: 'Un mineral mágico para hacer oro y una bebida para no morir jamás.',
        options: [
          { id: 'a', text: 'Fabricar plástico sintético y baterías de litio.', isCorrect: false },
          { id: 'b', text: 'La Piedra Filosofal (convertir metales en oro) y el Elixir de la Vida (inmortalidad).', isCorrect: true },
          { id: 'c', text: 'Descubrir la velocidad de la luz y la gravedad.', isCorrect: false },
          { id: 'd', text: 'Crear mapas astronómicos para viajar a la Luna.', isCorrect: false }
        ]
      },
      {
        id: 'm3_q2',
        missionId: 3,
        title: 'La Clasificación de Geber',
        prompt: 'El famoso alquimista árabe Geber (siglo VIII d.C.) clasificó las sustancias en tres grupos principales. ¿Cuáles son?',
        explanation: 'Geber clasificó la materia en: espíritus (volátiles como el alcohol), cuerpos metálicos (los metales) y cuerpos (sólidos no volátiles).',
        hint: 'Incluye sustancias volátiles que se evaporan, metales y sólidos.',
        options: [
          { id: 'a', text: 'Sólidos, líquidos, gases y plasma.', isCorrect: false },
          { id: 'b', text: 'Agua, aire, fuego y tierra.', isCorrect: false },
          { id: 'c', text: 'Ácidos, bases y sales neutras.', isCorrect: false },
          { id: 'd', text: 'Espíritus (volátiles), cuerpos metálicos y cuerpos (sólidos no volátiles).', isCorrect: true }
        ]
      },
      {
        id: 'm3_q3',
        missionId: 3,
        title: 'Paracelso y la Medicina',
        prompt: '¿A qué famoso alquimista (1493-1541) se le reconoce como el precursor de la química farmacéutica o Iatroquímica por usar químicos para curar enfermedades?',
        explanation: 'Paracelso revolucionó la medicina aplicando remedios alquímicos y químicos para tratar enfermedades específicas.',
        hint: 'Su nombre empieza con P y dio origen a la Iatroquímica.',
        options: [
          { id: 'a', text: 'Paracelso', isCorrect: true },
          { id: 'b', text: 'Hermes Trimegisto', isCorrect: false },
          { id: 'c', text: 'Zósimo de Panópolis', isCorrect: false },
          { id: 'd', text: 'Antoine Lavoisier', isCorrect: false }
        ]
      },
      {
        id: 'm3_q4',
        missionId: 3,
        title: 'Aparatos e Inventos de Laboratorio',
        prompt: '¿Qué instrumentos y métodos de laboratorio esenciales fueron inventados o perfeccionados por los alquimistas?',
        explanation: 'Los alquimistas desarrollaron el alambique, el baño María, la destilación, cristalización y el agua regia.',
        hint: 'Piensa en el recipiente calentado al vapor de agua y el destilador con cuello curvo.',
        options: [
          { id: 'a', text: 'El microscopio electrónico y el espectrómetro de masas.', isCorrect: false },
          { id: 'b', text: 'El mechero Bunsen y la centrifugadora digital.', isCorrect: false },
          { id: 'c', text: 'El alambique, el baño María, el agua regia y la destilación.', isCorrect: true },
          { id: 'd', text: 'El barómetro de mercurio y el termómetro digital.', isCorrect: false }
        ]
      },
      {
        id: 'm3_q5',
        missionId: 3,
        title: 'La Escuela de Alejandría',
        prompt: '¿Quién fue el alquimista (300 d.C.) reconocido por fundar una importante escuela de alquimia en Alejandría?',
        explanation: 'Zósimo de Panópolis fue una de las figuras históricas más documentadas que estableció la escuela de Alejandría.',
        hint: 'Su nombre comienza con Z.',
        options: [
          { id: 'a', text: 'Geber', isCorrect: false },
          { id: 'b', text: 'Zósimo de Panópolis', isCorrect: true },
          { id: 'c', text: 'Paracelso', isCorrect: false },
          { id: 'd', text: 'Robert Boyle', isCorrect: false }
        ]
      },
      {
        id: 'm3_q6',
        missionId: 3,
        title: 'El Poder del Agua Regia',
        prompt: '¿Qué es el "Agua Regia" descubierta por los alquimistas y por qué era tan famosa?',
        explanation: 'Es una mezcla potente de ácidos capaz de disolver metales nobles como el oro.',
        hint: 'Su nombre hace referencia a disolver el rey de los metales (el oro).',
        options: [
          { id: 'a', text: 'Agua purificada tres veces en las montañas.', isCorrect: false },
          { id: 'b', text: 'Un perfume elaborado a base de aceites reales de rosas.', isCorrect: false },
          { id: 'c', text: 'Agua de mar hervida con sal de cocina.', isCorrect: false },
          { id: 'd', text: 'Una mezcla corrosiva de ácidos capaz de disolver metales nobles como el oro.', isCorrect: true }
        ]
      }
    ]
  },
  {
    id: 4,
    title: 'Misión 4: La Revolución Científica: Flogisto vs Química Moderna',
    subtitle: 'Del Principio Inflamable a la Ley de Conservación',
    stageName: 'Flogisto y Química Moderna',
    description: 'Enfréntate al enigma del fuego: contrasta la errónea Teoría del Flogisto con las mediciones cuantitativas de Lavoisier y el descubrimiento del oxígeno.',
    icon: 'FlaskConical',
    color: 'emerald',
    questions: [
      {
        id: 'm4_q1',
        missionId: 4,
        title: 'La Teoría del Flogisto',
        prompt: '¿Qué postulaban Johann Becher y Georg Stahl en la teoría del flogisto (1700-1777)?',
        explanation: 'Postulaban que toda sustancia inflamable contenía un "principio inflamable" (flogisto) que se desprendía al arder. Creían que la madera tenía flogisto pero sus cenizas no.',
        hint: 'Se trataba de una sustancia misteriosa que supuestamente escapaba volando durante el fuego.',
        options: [
          { id: 'a', text: 'Que el oxígeno se combinaba con el carbono produciendo dióxido de carbono.', isCorrect: false },
          { id: 'b', text: 'Que los átomos no cambiaban de peso al quemarse.', isCorrect: false },
          { id: 'c', text: 'Que las sustancias combustibles contenían un "principio inflamable" (flogisto) que se perdía al arder.', isCorrect: true },
          { id: 'd', text: 'Que las cenizas pesaban el doble que la madera original.', isCorrect: false }
        ]
      },
      {
        id: 'm4_q2',
        missionId: 4,
        title: 'Antoine Laurent Lavoisier',
        prompt: '¿Por qué se considera a Antoine Laurent Lavoisier como el "Padre de la Química Moderna"?',
        explanation: 'Destruyó la teoría del flogisto al demostrar que la combustión ocurre por la combinación con el oxígeno del aire, introdujo la rigurosidad cuantitativa y la Ley de Conservación de la Materia.',
        hint: 'Aportó la balanza de precisión y demostró el papel real del oxígeno en el fuego.',
        options: [
          { id: 'a', text: 'Porque demostró que la combustión requiere oxígeno, destruyó la teoría del flogisto y formuló la Ley de Conservación de la Materia.', isCorrect: true },
          { id: 'b', text: 'Porque fue el primero en fabricar vidrio y bronce en Egipto.', isCorrect: false },
          { id: 'c', text: 'Porque inventó el alambique y la piedra filosofal.', isCorrect: false },
          { id: 'd', text: 'Porque propuso que el agua es el único elemento del universo.', isCorrect: false }
        ]
      },
      {
        id: 'm4_q3',
        missionId: 4,
        title: 'La Ley de Conservación de la Materia',
        prompt: '¿En qué año demostró Lavoisier la célebre Ley de la Conservación de la Materia ("la materia no se crea ni se destruye, solo se transforma")?',
        explanation: 'En 1785, Lavoisier demostró experimentalmente esta ley fundamental utilizando mediciones cuantitativas precisas.',
        hint: 'Fue en la década de 1780, unos años antes de la Revolución Francesa.',
        options: [
          { id: 'a', text: 'En 1200 a.C.', isCorrect: false },
          { id: 'b', text: 'En 1600 d.C.', isCorrect: false },
          { id: 'c', text: 'En 1950', isCorrect: false },
          { id: 'd', text: 'En 1785', isCorrect: true }
        ]
      },
      {
        id: 'm4_q4',
        missionId: 4,
        title: 'El Descubrimiento del Oxígeno',
        prompt: '¿Qué científico (1733-1804) descubrió el gas fundamental llamado Oxígeno, indispensable para la respiración y la combustión?',
        explanation: 'Joseph Priestley aisló por primera vez el gas oxígeno en el siglo XVIII.',
        hint: 'Su apellido en inglés se traduce como relativo a "sacerdote".',
        options: [
          { id: 'a', text: 'John Dalton', isCorrect: false },
          { id: 'b', text: 'Joseph Priestley', isCorrect: true },
          { id: 'c', text: 'Demócrito', isCorrect: false },
          { id: 'd', text: 'Paracelso', isCorrect: false }
        ]
      },
      {
        id: 'm4_q5',
        missionId: 4,
        title: 'El Método Cuantitativo y Robert Boyle',
        prompt: '¿Qué aporte relevante realizó Robert Boyle (1627-1691) a la transición hacia la química científica?',
        explanation: 'Robert Boyle promovió el estudio riguroso de los gases y la química cualitativa y experimental comprobable.',
        hint: 'Es famoso por sus estudios sobre la presión y volumen de los gases.',
        options: [
          { id: 'a', text: 'Descubrió la fisión nuclear.', isCorrect: false },
          { id: 'b', text: 'Inventó la dinamita.', isCorrect: false },
          { id: 'c', text: 'Introdujo el estudio sistemático de los gases y el método experimental comprobable.', isCorrect: true },
          { id: 'd', text: 'Creó el primer microscopio de luz.', isCorrect: false }
        ]
      },
      {
        id: 'm4_q6',
        missionId: 4,
        title: 'El Tratado Elemental de Química',
        prompt: '¿En qué año publicó Lavoisier su obra cumbre, el "Tratado Elemental de Química", donde estableció la definición moderna de elemento químico?',
        explanation: 'En 1789 Lavoisier publicó el Tratado Elemental de Química, hito que consolidó la Química como una ciencia moderna independiente.',
        hint: 'Coincide con el año de inicio de la Revolución Francesa (1789).',
        options: [
          { id: 'a', text: 'En 1789', isCorrect: true },
          { id: 'b', text: 'En 1500', isCorrect: false },
          { id: 'c', text: 'En 1910', isCorrect: false },
          { id: 'd', text: 'En 1650', isCorrect: false }
        ]
      }
    ]
  }
];
